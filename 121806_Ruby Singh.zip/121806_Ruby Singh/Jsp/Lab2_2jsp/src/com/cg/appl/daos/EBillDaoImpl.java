package com.cg.appl.daos;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;

import com.cg.appl.dto.Bill;
import com.cg.appl.dto.Consumer;
import com.cg.appl.exceptions.BillException;
import com.cg.appl.util.DbUtil;

public class EBillDaoImpl implements EBillDao {
    private DbUtil util;
	public EBillDaoImpl() throws BillException {
		util=new DbUtil();
	}

	@Override
	public boolean updateBill(Bill bill) throws BillException{
		
		Connection conn=null;
		PreparedStatement pst=null;
		String query="INSERT INTO BILLDETAILS (BILL_NUM,"
				+ "CONSUMER_NUM,CUR_READING,UNITCONSUMED,NETAMOUNT,BILL_DATE)"
				+ "VALUES(?,?,?,?,?,sysdate) ";
		
		try{
			conn=util.getConnection();
			pst=conn.prepareStatement(query);
			pst.setInt(1,bill.getBillNum());
			pst.setInt(2,bill.getConsumerNum());
			pst.setFloat(3,bill.getCurReading());
			pst.setFloat(4,bill.getUnitconsumed());
			pst.setFloat(5,bill.getNetAmount());
			
			int rec=pst.executeUpdate();
			if(rec>0)
				return true;
		}catch(SQLException e){
			e.printStackTrace();
			throw new BillException("Failed to update");
		}finally{
			try{
				if(pst!=null){
					pst.close();
				}
				if(conn!=null){
					conn.close();
				}
			}catch(SQLException e){
				e.printStackTrace();
			}
		}
		return false;
	}

	@Override
	public int generateBillNum() throws BillException {
		Connection conn=null;
		PreparedStatement pst=null;
		String query="SELECT seq_bill_num.NEXTVAL FROM DUAL";
		int billNum=0;
		try{
		conn=util.getConnection();
		pst=conn.prepareStatement(query);
		ResultSet rs=pst.executeQuery();
		while(rs.next()){
	    billNum=rs.getInt(1);
		}
		}catch(SQLException e){
			e.printStackTrace();
			//e.getMessage();
			throw new BillException("failed to generate bill number"+e);
		}finally{
			try{
				if(pst!=null){
					pst.close();
				}
				if(conn!=null){
					conn.close();
				}
			}catch(SQLException e){
				e.printStackTrace();
			}
		}
		
		return billNum;
	}

	@Override
	public Consumer obtainConsumer(int consumerNum) throws BillException {
	
		Connection conn=null;
		PreparedStatement pst=null;
		String query="SELECT CONSUMER_NAME,ADDRESS FROM CONSUMERS WHERE CONSUMER_NUM=?";
			try{
				conn=util.getConnection();
				pst=conn.prepareStatement(query);
				pst.setInt(1,consumerNum);
				ResultSet rs=pst.executeQuery();
				if(rs.next()){
				String consumerName=rs.getString("CONSUMER_NAME");
				String address=rs.getString("ADDRESS");
				Consumer consumer=new Consumer(consumerNum,consumerName,address);
				return consumer;
				}
			}catch(SQLException e){
				e.printStackTrace();
				//e.getMessage();
				throw new BillException("Consumer does not exist"+e);
			}finally{
				try{
					if(pst!=null){
						pst.close();
					}
					if(conn!=null){
						conn.close();
					}
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		  return null;
	}

	@Override
	public List<Consumer> showAllConsumers() throws BillException {
		Connection conn=null;
		PreparedStatement pst=null;
		List<Consumer> myList=new ArrayList<>();
		String query="SELECT CONSUMER_NUM,CONSUMER_NAME,ADDRESS FROM CONSUMERS";
		try{
			conn=util.getConnection();
			pst=conn.prepareStatement(query);
			ResultSet rs=pst.executeQuery();
			while(rs.next()){
				Consumer consumer = new Consumer();
				consumer.setConsumerNum(rs.getInt("CONSUMER_NUM"));
				consumer.setConsumerName(rs.getString("CONSUMER_NAME"));
				consumer.setAddress(rs.getString("ADDRESS"));
				myList.add(consumer);
			}
			return myList;
		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			try{
				if(pst!=null){
					pst.close();
				}
				if(conn!=null){
					conn.close();
				}
			}catch(SQLException e){
				e.printStackTrace();
			}
		}
		return null;
	}

	@Override
	public List<Bill> getBillDetails(int consumerNum) throws BillException {
		Connection conn=null;
		PreparedStatement pst=null;
		List<Bill> myList=new ArrayList<>();
		String query="SELECT BILL_NUM,CUR_READING,UNITCONSUMED,"
				+ "NETAMOUNT,BILL_DATE FROM BILLDETAILS WHERE CONSUMER_NUM=?";
		try{
			conn=util.getConnection();
			pst=conn.prepareStatement(query);
			pst.setInt(1, consumerNum);
			ResultSet rs=pst.executeQuery();
			while(rs.next()){
				Bill bill=new Bill();
				bill.setBillNum(rs.getInt("BILL_NUM"));
				bill.setConsumerNum(consumerNum);
				bill.setCurReading(rs.getFloat("CUR_READING"));
				bill.setUnitconsumed(rs.getFloat("UNITCONSUMED"));
				bill.setNetAmount(rs.getFloat("NETAMOUNT"));
				Date date=rs.getDate("BILL_DATE");
				LocalDate localDate=date.toLocalDate();
				Month billMonth=localDate.getMonth();
				bill.setBillDate(billMonth.toString());
				
				myList.add(bill);
			}
			return myList;
		}catch(SQLException e){
			throw new BillException("No data found"+e);
		}finally{
			try{
				if(pst!=null){
					pst.close();
				}
				if(conn!=null){
					conn.close();
				}
			}catch(SQLException e){
				e.printStackTrace();
			}
		}
	}

	

}
