package com.cg.appl.services;

import java.util.List;

import com.cg.appl.dto.Bill;
import com.cg.appl.dto.Consumer;
import com.cg.appl.exceptions.BillException;

public interface EBillService {
	boolean updateBill(Bill bill)throws BillException;

	int generateBillNum()throws BillException;

	Consumer obtainConsumer(int consumerNum)throws BillException;

	boolean isValidConsumer(int consumerNum);

	boolean isValidReading(float curReading, float lastReading);

	List<Consumer> showAllConsumers()throws BillException;

	List<Bill> getBillDetails(int consumerNum)throws BillException;


	
}
