package com.cg.appl.exceptions;

public class BillException extends Exception {

	public BillException() {
		
	}

	public BillException(String arg0) {
		super(arg0);
		
	}
}
