package com.capgemini.app;

import static org.junit.Assert.*;

import org.junit.Test;


/**
 * Unit test for simple App.
 */
public class AppTest 
    
{
    /**
     * Create the test case
     */

	@Test
    public void testApp()
    {
        assertTrue( true );
    }
}
