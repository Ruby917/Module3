package com.cg.ebillapplication.dto;

public class ConsumerDto {
	private String cust_name;
	private String cust_addr;
	private int customerNo;

	public ConsumerDto() {

	}

	public ConsumerDto(String cust_name, String cust_addr, int customerNo) {
		super();
		this.cust_name = cust_name;
		this.cust_addr = cust_addr;
		this.customerNo = customerNo;
	}

	public String getCust_name() {
		return cust_name;
	}

	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}

	public String getCust_addr() {
		return cust_addr;
	}

	public void setCust_addr(String cust_addr) {
		this.cust_addr = cust_addr;
	}

	public int getCustomerNo() {
		return customerNo;
	}

	public void setCustomerNo(int customerNo) {
		this.customerNo = customerNo;
	}

	@Override
	public String toString() {
		return "ConsumerDto [cust_name=" + cust_name + ", cust_addr="
				+ cust_addr + ", customerNo=" + customerNo + "]";
	}
	
}
