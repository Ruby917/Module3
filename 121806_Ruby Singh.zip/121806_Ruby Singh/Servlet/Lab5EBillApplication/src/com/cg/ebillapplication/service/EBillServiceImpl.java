package com.cg.ebillapplication.service;

import java.util.List;
import java.util.regex.Pattern;

import com.cg.ebillapplication.dao.EBillDAO;
import com.cg.ebillapplication.dao.EBillDAOImpl;
import com.cg.ebillapplication.dto.BillDTO;
import com.cg.ebillapplication.dto.ConsumerDto;
import com.cg.ebillapplication.exception.EbillException;

public class EBillServiceImpl implements EBillService{
	EBillDAO billdao = null;
	public EBillServiceImpl() throws EbillException {
		billdao = new EBillDAOImpl();
	}

	@Override
	public int addBillDetails(ConsumerDto con,BillDTO bill) throws EbillException {
		return billdao.addBillDetails(con,bill);
	}
	
	@Override
	public List<Integer> checkConsumerNumber() throws EbillException {
		return  billdao.checkConsumerNumber();
	}

	@Override
	public String getCunsumername(int cno) throws EbillException {
		return billdao.getCunsumername(cno);
	} 
	
	/*public void validateConsumerNo(String patt,String name) throws EbillException{
		boolean value=Pattern.matches(patt,name);
		if(!value){
			throw new EbillException("consumer number should be of 6 digit and should not start with 0");
		}
	}*/

	
}
