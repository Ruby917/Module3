package com.cg.ebillapplication.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import com.cg.ebillapplication.dto.BillDTO;
import com.cg.ebillapplication.dto.ConsumerDto;
import com.cg.ebillapplication.exception.EbillException;
import com.cg.ebillapplication.util.DBUtil;

public class EBillDAOImpl implements EBillDAO{
	private DBUtil util;
	Connection conn = null;
	PreparedStatement pstmt = null;
	public EBillDAOImpl() throws EbillException {
		util = new DBUtil();
	}

	@Override
	public int addBillDetails(ConsumerDto con,BillDTO bill) throws EbillException {
		int status=0;
		int bno = getBillNo();
		try {
			conn = util.getConnection();
			String query="INSERT INTO BILLDETAILS VALUES(?,?,?,?,?,?)";
			pstmt=conn.prepareStatement(query);
			pstmt.setInt(1, bno);
			pstmt.setInt(2, con.getCustomerNo());
			pstmt.setDouble(3, bill.getCurrentMonthReading());
			pstmt.setDouble(4, bill.getUnitConsumed());
			pstmt.setDouble(5, bill.getNetAmount());
			Calendar calendar = Calendar.getInstance();
		    java.sql.Date currentDate = new java.sql.Date(calendar.getTime().getTime());
		    pstmt.setDate(6,currentDate);
			status=pstmt.executeUpdate();
			if(status==1){
				System.out.println("data inserted");
			}
			else{
				System.out.println("data not inserted");
			}
		} catch (SQLException e) {
			throw new EbillException("Exception in sql");
		}finally{
			try {
				if(pstmt!=null){
					pstmt.close();
				}
				if(conn!=null){
					conn.close();
				}
			} catch (SQLException e) {
				throw new EbillException("Database closing failed");
			}
		}
		return bno;
	}
	public List<BillDTO> displayBillDetails() throws EbillException{
		List<BillDTO> blist = new ArrayList<BillDTO>();
		try {
			conn = util.getConnection();
			String query = "SELECT C.CONSUMER_NUM,C.CONSUMER_NAME,B.UNITCONSUMED,B.NETAMOUNT FROM CONSUMERS C,BILLDETAILS B WHERE C.CONSUMER_NUM=B.CONSUMER_NUM";
			pstmt = conn.prepareStatement(query);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()){
				BillDTO b = new BillDTO();
				ConsumerDto con = new ConsumerDto();
				
				con.setCustomerNo(rs.getInt(1));
				con.setCust_name(rs.getString(2));
				b.setUnitConsumed(rs.getDouble(3));
				b.setNetAmount(rs.getDouble(4));
				blist.add(b);
			}
			rs.close();
		} catch (SQLException e) {
			throw new EbillException("Exception in sql");
		}finally{
			try {
				if(pstmt!=null){
					pstmt.close();
				}
				if(conn!=null){
					conn.close();
				}
			} catch (SQLException e) {
				throw new EbillException("Database closing failed");
			}
		}
		return blist;
	}
	
	public List<Integer> checkConsumerNumber() throws EbillException{
		List<Integer> blist = new ArrayList<Integer>();
		try {
			conn = util.getConnection();
			String query = "SELECT CONSUMER_NUM FROM CONSUMERS";
			pstmt = conn.prepareStatement(query);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()){
				blist.add(rs.getInt(1));
			}
		} catch (SQLException e) {
			throw new EbillException("Exception in sql");
		}finally{
			try {
				if(pstmt!=null){
					pstmt.close();
				}
				if(conn!=null){
					conn.close();
				}
			} catch (SQLException e) {
				throw new EbillException("Database closing failed");
			}
		}
		return blist;
	}
	public String getCunsumername(int cno) throws EbillException{
		String cname = null;
		try {
			conn = util.getConnection();
			String query = "SELECT CONSUMER_NAME FROM CONSUMERS WHERE CONSUMER_NUM=?";
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, cno);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()){
				cname = rs.getString(1);
			}
		} catch (SQLException e) {
			throw new EbillException("Exception in sql");
		}finally{
			try {
				if(pstmt!=null){
					pstmt.close();
				}
				if(conn!=null){
					conn.close();
				}
			} catch (SQLException e) {
				throw new EbillException("Database closing failed");
			}
		}
		return cname;
	}

	private int getBillNo() throws EbillException {
		int billNo=0;
		String query="SELECT seq_bill_num.NEXTVAL FROM DUAL";
		Connection conn=null;
		PreparedStatement ps=null;
		
		try {
			conn=util.getConnection();
			ps=conn.prepareStatement(query);
			ResultSet res=ps.executeQuery();
			while(res.next()){
			billNo=res.getInt(1);
			}
			
		} catch (SQLException e) {
			throw new EbillException("Exception in sql");
		}
		finally{
			try {
				if(pstmt!=null){
					pstmt.close();
				}
				if(conn!=null){
					conn.close();
				}
			} catch (SQLException e) {
				throw new EbillException("Database closing failed");
			}
		}
		return billNo;

	
	}
}
