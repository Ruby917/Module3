package com.cg.ebillapplication.dto;

import java.sql.Date;

public class BillDTO {
	private int billNo;
	private double lastMonthReading;
	private double CurrentMonthReading;
	private double unitConsumed;
	private double netAmount;
	private Date billDate;
	
	public BillDTO() {
		super();
	}

	public int getBillNo() {
		return billNo;
	}

	public void setBillNo(int billNo) {
		this.billNo = billNo;
	}

	public double getLastMonthReading() {
		return lastMonthReading;
	}

	public void setLastMonthReading(double lastMonthReading) {
		this.lastMonthReading = lastMonthReading;
	}

	public double getCurrentMonthReading() {
		return CurrentMonthReading;
	}

	public void setCurrentMonthReading(double currentMonthReading) {
		CurrentMonthReading = currentMonthReading;
	}

	public double getUnitConsumed() {
		return unitConsumed;
	}

	public void setUnitConsumed(double unitConsumed) {
		this.unitConsumed = unitConsumed;
	}

	public double getNetAmount() {
		return netAmount;
	}

	public void setNetAmount(double netAmount) {
		this.netAmount = netAmount;
	}

	public Date getBillDate() {
		return billDate;
	}

	public void setBillDate(Date billDate) {
		this.billDate = billDate;
	}

	

	@Override
	public String toString() {
		return "BillDTO [billNo=" + billNo + ", lastMonthReading="
				+ lastMonthReading + ", CurrentMonthReading="
				+ CurrentMonthReading + ", unitConsumed=" + unitConsumed
				+ ", netAmount=" + netAmount + ", billDate=" + billDate + "]";
	}

	public BillDTO(String cust_name, String cust_addr, int billNo,
			int customerNo, double lastMonthReading,
			double currentMonthReading, double unitConsumed, double netAmount,
			Date billDate) {
		super();
		this.billNo = billNo;
		this.lastMonthReading = lastMonthReading;
		this.CurrentMonthReading = currentMonthReading;
		this.unitConsumed = unitConsumed;
		this.netAmount = netAmount;
		this.billDate = billDate;
	}

	

	
	
}
