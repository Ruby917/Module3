package com.cg.lab3_2.service;

import com.cg.lab3_2.dto.UserDto;
import com.cg.lab3_2.exception.RegistrationException;

public interface IRegisterService {
	public int addRegistrationDetails(UserDto user) throws RegistrationException;

}
