package com.cg.appl.Services;

import com.cg.appl.UserException.UserException;
import com.cg.appl.entities.BillDetails;

public interface UserMasterServices {
	com.cg.appl.entities.User getUserDetails(String userName)
			throws UserException;

	boolean isUserAuthenticated(String username, String Password)
			throws UserException;
	
    boolean consumer(BillDetails b,double lastreading) throws UserException;
}
