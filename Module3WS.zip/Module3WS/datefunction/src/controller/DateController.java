package controller;

import java.io.IOException;
import java.text.ParseException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import exception.DateException;
import service.Dateservice;
import service.DateseviceImpl;


@WebServlet("*.do")
public class DateController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	Dateservice ds = null;
	public DateController() throws DateException {
		ds = new DateseviceImpl();
	}
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			try {
				processRequest(request,response);
			} catch (DateException e) {
				e.printStackTrace();
			} catch (ParseException e) {
				e.printStackTrace();
			}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			processRequest(request,response);
		} catch (DateException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}

	}
	
    private void processRequest(HttpServletRequest request,HttpServletResponse response) throws DateException, ServletException, IOException, ParseException {
		String path = request.getServletPath();
		System.out.println(path);
		if(path.equals("/getDate.do")){
			String datestr = request.getParameter("date");
			System.out.println(datestr);
			
			Date date = Date.valueOf(datestr);

			ds.getDateofBirth(date);
			request.setAttribute("d", date);
			 RequestDispatcher dispatch = request.getRequestDispatcher("new.jsp");
	 			dispatch.forward(request, response);
		}else if(path.equals("/showDate.do")){
			List<Date> l = new ArrayList<Date>();
			l = ds.showDateofBirth();
			request.setAttribute("dob",l);
			 RequestDispatcher dispatch = request.getRequestDispatcher("showDateofBirth.jsp");
 			dispatch.forward(request, response);
		}
    	
	}

}
