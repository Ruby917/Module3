package service;

import java.sql.Date;
import java.util.List;

import exception.DateException;

public interface Dateservice {
	public int getDateofBirth(Date d) throws DateException;
	public List<Date> showDateofBirth() throws DateException;
}
