package service;

import java.sql.Date;
import java.util.List;

import dao.DatedaoImpl;
import dao.IDatedao;
import exception.DateException;

public class DateseviceImpl implements Dateservice{
	IDatedao datedao = null;
	public DateseviceImpl() throws DateException {
		datedao = new DatedaoImpl();
	}

	@Override
	public int getDateofBirth(Date d) throws DateException {
		return datedao.getDateofBirth(d);
	}

	@Override
	public List<Date> showDateofBirth() throws DateException {
		return datedao.showDateofBirth();
	}

}
