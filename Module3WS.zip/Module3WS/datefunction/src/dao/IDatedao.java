package dao;

import java.sql.Date;
import java.util.List;

import exception.DateException;

public interface IDatedao {
	public int getDateofBirth(Date d) throws DateException;
	public List<Date> showDateofBirth() throws DateException;
}
