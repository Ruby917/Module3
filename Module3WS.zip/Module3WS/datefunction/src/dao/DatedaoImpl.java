package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import java.util.ArrayList;
import java.util.List;

import exception.DateException;
import util.DBUtil;


public class DatedaoImpl implements IDatedao{
	private DBUtil util;
	Connection conn = null;
	PreparedStatement pstmt = null;
	
	public DatedaoImpl() throws DateException{
		util = new DBUtil();
	}

	@Override
	public int getDateofBirth(Date d) throws DateException {
		int status = 0;
		try {
			conn = util.getConnection();
			String query="INSERT INTO DOB VALUES(?)";
			pstmt=conn.prepareStatement(query);
			pstmt.setDate(1, d);
			status=pstmt.executeUpdate();
			if(status==1){
				System.out.println("data inserted");
			}
			else{
				System.out.println("data not inserted");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				if(pstmt!=null){
					pstmt.close();
				}
				if(conn!=null){
					conn.close();
				}
			} catch (SQLException e) {
				throw new DateException("Database closing failed");
			}
		}
		return status;
	}

	@Override
	public List<Date> showDateofBirth() throws DateException {
		ResultSet rs = null;
		List<Date> blist = new ArrayList<Date>();
		Date d ;
		try {
			conn = util.getConnection();
			String query = "SELECT DATEOFBIRTH FROM DOB";
			pstmt = conn.prepareStatement(query);
			rs = pstmt.executeQuery();
			while(rs.next()){
				System.out.println(blist);
				 d = rs.getDate(1);
				blist.add(d);
				System.out.println(blist);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				if(rs!=null){
					rs.close();
				}
				if(pstmt!=null){
					pstmt.close();
				}
				if(conn!=null){
					conn.close();
				}
			} catch (SQLException e) {
				throw new DateException("Database closing failed");
			}
		}
		System.out.println(blist);
		return blist;
	}
	

}
