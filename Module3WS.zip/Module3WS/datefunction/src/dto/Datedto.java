package dto;

import java.sql.Date;

public class Datedto {

	private Date dofb;

	public Datedto(Date dofb) {
		super();
		this.dofb = dofb;
	}

	public Date getDofb() {
		return dofb;
	}

	public void setDofb(Date dofb) {
		this.dofb = dofb;
	}

	@Override
	public String toString() {
		return "Datedto [dofb=" + dofb + "]";
	}


}
