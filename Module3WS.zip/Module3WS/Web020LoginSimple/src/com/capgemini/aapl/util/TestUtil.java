package com.capgemini.aapl.util;

import java.sql.Connection;
import java.sql.SQLException;


public class TestUtil {
	public static void main(String[] args) {
		DBUtil util = new DBUtil();
		Connection conn;
		try {
			conn = util.getConnection();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

}
