package com.capgemini.aapl.services;

import com.capgemini.aapl.entities.User;
import com.capgemini.aapl.exceptions.UserException;

public interface UserMasterServices {
	User getUserDetails(String userName) throws UserException;
	boolean isUserAuthenticated(String userName,String password) throws UserException;

}
