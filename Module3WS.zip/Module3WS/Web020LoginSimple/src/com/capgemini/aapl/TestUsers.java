package com.capgemini.aapl;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.aapl.entities.User;
import com.capgemini.aapl.exceptions.UserException;
import com.capgemini.aapl.services.UserMasterServices;
import com.capgemini.aapl.services.UserMasterServicesImpl;

public class TestUsers {
	private static UserMasterServices services = null;
	
	@BeforeClass
	public static void initialize(){
		services = new UserMasterServicesImpl();
	}

	@Test
	public void testGetUserDetails() {
		try {
			User user = services.getUserDetails("b");
			String actualPassword = "b";
			System.out.println(user);
		    assertEquals(user.getPassword(),actualPassword);
		} catch (UserException e) { 
			System.out.println(e);
			e.printStackTrace();
		}
	}

}
