package com.capgemini.aapl.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.aapl.entities.User;
import com.capgemini.aapl.exceptions.UserException;
import com.capgemini.aapl.util.DBUtil;

public class UserMasterDaoImpl implements UserMasterDao {
	private DBUtil util = null;

	public UserMasterDaoImpl() {
		util = new DBUtil();
		}

	@Override
	public User getUserDetails(String userName) throws UserException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String qry = "SELECT USERNAME,PASSWORD,USERFULLNAME FROM USERS WHERE USERNAME = ?";
		try {
			conn = util.getConnection();
			pstmt = conn.prepareStatement(qry);
			pstmt.setString(1, userName);
			
			rs = pstmt.executeQuery();
			if(rs.next()){
				String password = rs.getString("PASSWORD");
				String fullName = rs.getString("USERFULLNAME");
				
				User user = new User(userName,password,fullName);
				return user;
			}else{
				throw new UserException("Database not connected");
			}
		} catch (SQLException e) {
			throw new UserException("Database not connected",e);
		}finally{
			try {
				if(rs!=null){
						rs.close();
				}
				if(pstmt!=null){
					pstmt.close();
				}
				if(conn!=null){
					conn.close();
				}
			} catch (SQLException e) {
				throw new UserException("Database not connected",e);
			}
		}
	}

}
