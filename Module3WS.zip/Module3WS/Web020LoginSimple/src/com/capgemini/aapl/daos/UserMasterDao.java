package com.capgemini.aapl.daos;

import com.capgemini.aapl.entities.User;
import com.capgemini.aapl.exceptions.UserException;

public interface UserMasterDao {
	User getUserDetails(String userName) throws UserException;
	

}
