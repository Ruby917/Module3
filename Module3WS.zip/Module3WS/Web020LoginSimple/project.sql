select * from emp;
drop table users;
create table users (
username varchar2(15) primary key,
password varchar2(15),
userfullname varchar(40)
);

insert into users(username,password,userfullname) values('a','b','Ruby Singh');
insert into users(username,password,userfullname) values('b','b','Riya Gupta');

select * from users;