package com.cg.appl.dto;
public class Bill {

	
	private int billNum;
	private int consumerNum;
	private float curReading;
	private float lastReading;
	private float unitconsumed;
	private float netAmount;
	private String billDate;
	
	public Bill() {
		
	}

	public Bill(int billNum,int consumerNum,float curReading,
			float unitconsumed, float netAmount) {
		super();
		this.billNum = billNum;
		this.consumerNum=consumerNum;
		this.curReading = curReading;
		this.unitconsumed = unitconsumed;
		this.netAmount = netAmount;
	}
	
	public float getLastReading() {
		return lastReading;
	}

	public void setLastReading(float lastReading) {
		this.lastReading = lastReading;
	}

	public String getBillDate() {
		return billDate;
	}

	public void setBillDate(String billDate) {
		this.billDate = billDate;
	}

	public int getConsumerNum() {
		return consumerNum;
	}

	public void setConsumerNum(int consumerNum) {
		this.consumerNum = consumerNum;
	}

	public int getBillNum() {
		return billNum;
	}

	public void setBillNum(int billNum) {
		this.billNum = billNum;
	}

	public float getCurReading() {
		return curReading;
	}

	public void setCurReading(float curReading) {
		this.curReading = curReading;
	}

	public float getUnitconsumed() {
		return unitconsumed;
	}

	public void setUnitconsumed(float unitconsumed) {
		this.unitconsumed = unitconsumed;
	}

	public float getNetAmount() {
		return netAmount;
	}

	public void setNetAmount(float netAmount) {
		this.netAmount = netAmount;
	}

	@Override
	public String toString() {
		return "Bill [billNum=" + billNum + ", consumerNum=" + consumerNum
				+ ", curReading=" + curReading + ", unitconsumed="
				+ unitconsumed + ", netAmount=" + netAmount + ", billDate="
				+ billDate + "]"+"\n";
	}
	
	
}
