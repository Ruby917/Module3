package com.cg.appl.services;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.appl.daos.EBillDao;
import com.cg.appl.daos.EBillDaoImpl;
import com.cg.appl.dto.Bill;
import com.cg.appl.dto.Consumer;
import com.cg.appl.exceptions.BillException;

public class EBillServiceImpl implements EBillService {
    private EBillDao dao;
	public EBillServiceImpl() throws BillException {
		dao=new EBillDaoImpl();
	}

	@Override
	public boolean updateBill(Bill bill) throws BillException {
		return dao.updateBill(bill);
	}

	@Override
	public int generateBillNum() throws BillException {
		
		return dao.generateBillNum();
	}

	@Override
	public Consumer obtainConsumer(int consumerNum) throws BillException {
		return dao.obtainConsumer(consumerNum);
	}

	@Override
	public boolean isValidConsumer(int consumerNum) {
		String patt="[1-9][0-9]{5}";
		Pattern pattern=Pattern.compile(patt);
		Matcher matcher=pattern.matcher(Integer.toString(consumerNum));
		if(matcher.matches()){
			return true;
		}
		else{		
		return false;
		}
	}

	@Override
	public boolean isValidReading(float curReading, float lastReading) {
		if(curReading>0 && lastReading>0)
		{
			if(curReading>lastReading){
				
		        	String patt="[0-9]*\\.?[0-9]{0,2}";
		 			Pattern pattern=Pattern.compile(patt);
		 			Matcher matcher=pattern.matcher(Float.toString(curReading));
		 			
		 			String patt1="[0-9]*\\.?[0-9]{0,2}";
		 			Pattern pattern1=Pattern.compile(patt1);
		 			Matcher matcher1=pattern1.matcher(Float.toString(lastReading));
		 			
		 			if(matcher1.matches() && matcher.matches()){
		 			
			return true;
		}
		}
		}
	return false;
	}

	@Override
	public List<Consumer> showAllConsumers() throws BillException {
		return dao.showAllConsumers();
	}

	@Override
	public List<Bill> getBillDetails(int consumerNum) throws BillException {
		// TODO Auto-generated method stub
		return dao.getBillDetails(consumerNum);
	}

	
	

}
