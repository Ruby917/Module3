package com.cg.appl.controllers;

import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.appl.dto.Bill;
import com.cg.appl.dto.Consumer;
import com.cg.appl.exceptions.BillException;
import com.cg.appl.services.EBillService;
import com.cg.appl.services.EBillServiceImpl;

@WebServlet("*.do")
public class EBillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final int fixedCharge=100;
	private EBillService service;
	private Bill bill;
	private Consumer consumer;
       
   public void init(ServletConfig config) throws ServletException {
	   try {
		service=new EBillServiceImpl();
		 bill=new Bill();
		   consumer=new Consumer();
	} catch (BillException e) {
		e.printStackTrace();
	}
	  
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String path=request.getServletPath();
		if(path.equals("/eBill.do")){
		int consumerNum=Integer.parseInt(request.getParameter("consumerNum"));
		boolean b=service.isValidConsumer(consumerNum);
		
		if(!b){
			request.setAttribute("errorMsg","invalid consumer number");
			request.getRequestDispatcher("ErrorPage.jsp").forward(request,response);
		}
		
		float curReading=Float.parseFloat(request.getParameter("curReading"));
		float lastReading=Float.parseFloat(request.getParameter("lastReading"));
		b=service.isValidReading(curReading,lastReading);
		if(!b){
			request.setAttribute("errorMsg","current month meter reading is invalid");
			request.getRequestDispatcher("ErrorPage.jsp").forward(request,response);
		}
		
			float unitConsumed=curReading-lastReading;
		float netAmount = unitConsumed * 1.15f + fixedCharge;
		int billNum=0;
		try {
			billNum=service.generateBillNum();
		} catch (BillException e) {
			//e.printStackTrace();
			request.setAttribute("errorMsg","Error occured:"+"\n"+"No bill details for "+billNum);
			request.getRequestDispatcher("ErrorPage.jsp").forward(request,response);
		}
	    
		
		Bill bill=new Bill(billNum,consumerNum,curReading,unitConsumed,netAmount);
		
		try {
			if(service.updateBill(bill)){
				HttpSession session=request.getSession(true);
				consumer=service.obtainConsumer(consumerNum);
				
				session.setAttribute("consumerData",consumer);
				session.setAttribute("billData", bill);
				request.getRequestDispatcher("InfoViewPage.jsp").forward(request,response);
			}
			else
			{
				request.setAttribute("errorMsg","Invalid Consumer Number");
				request.getRequestDispatcher("ErrorPage.jsp").forward(request,response);
			}
		} catch (BillException e) {
			e.printStackTrace();
		}
				
		}	
		
		else 
			if(path.equals("/ConsumerList.do")){
			List<Consumer> myList=new ArrayList<>();
			try {
				myList=service.showAllConsumers();
				HttpSession session=request.getSession(true);
				session.setAttribute("data",myList);
				request.getRequestDispatcher("ShowAllConsumers.jsp").forward(request,response);
			} catch (BillException e) {
				//e.printStackTrace();
				e.getMessage();
			}
		}
			else 
				if(path.equals("/ShowBillDetails.do")){
					String id=request.getParameter("id");
					int consumerNum=Integer.parseInt(id);
					List<Bill> myList=new ArrayList<>();
					try {
						myList=service.getBillDetails(consumerNum);
						HttpSession session=request.getSession(true);
						session.setAttribute("cNo",consumerNum);
						session.setAttribute("billData",myList);
						request.getRequestDispatcher("Show_Bills.jsp").forward(request,response);
					} catch (BillException e) {
						//e.printStackTrace();
						e.getMessage();
					}
					
					
			}
		   else 
				if(path.equals("/SearchConsumer.do")){
					request.getRequestDispatcher("SearchConsumer.jsp").forward(request,response);
								
			}
				else 
					if(path.equals("/ShowConsumer.do")){
						int consumerNum=Integer.parseInt(request.getParameter("consumerNum"));
						try {
							consumer=service.obtainConsumer(consumerNum);
							HttpSession session=request.getSession(true);
							session.setAttribute("consumerData",consumer);
							request.getRequestDispatcher("Show_Consumer.jsp").forward(request,response);
						} catch (BillException e) {
							//e.printStackTrace();
							e.getMessage();
						}	
					}
					else 
						if(path.equals("/UserInfo.do")){
							String id=request.getParameter("id");
							int consumerNum=Integer.parseInt(id);
							request.setAttribute("cNo",consumerNum);
							request.getRequestDispatcher("UserInfoPage.jsp").forward(request,response);
						}
		
				  else 
					    if(path.equals("/Home.do")){
					    	HttpSession session=request.getSession(false);
							session.invalidate(); 
					    	request.getRequestDispatcher("index.jsp").forward(request,response);
					    }
	}

}
