package com.cg.appl.util;



import java.sql.Connection;
import java.sql.SQLException;

import com.cg.appl.exceptions.BillException;

import oracle.jdbc.pool.OracleDataSource;

public class DbUtil {
	
	
	private OracleDataSource dataSource;
	   public DbUtil() throws BillException{
			
		}
		
		public Connection getConnection() throws BillException{
			try {
				dataSource=new OracleDataSource();
				dataSource.setURL("jdbc:oracle:thin:@10.125.6.62:1521:ORCL11G");
				dataSource.setUser("labg104trg12");
				dataSource.setPassword("labg104oracle");
				dataSource.setDriverType("oracle");
				return dataSource.getConnection();
			}catch (SQLException e) {
				//e.printStackTrace();
				throw new BillException("Failed to connect"+e);
			}
			
		}

		@Override
		protected void finalize() throws Throwable {
			dataSource.close();
			super.finalize();
		}

}
