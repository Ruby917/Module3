package com.cg.appl.daos;

import java.util.List;

import com.cg.appl.dto.Bill;
import com.cg.appl.dto.Consumer;
import com.cg.appl.exceptions.BillException;

public interface EBillDao {
 boolean updateBill(Bill bill)throws BillException;

int generateBillNum()throws BillException;

Consumer obtainConsumer(int consumerNum)throws BillException;

List<Consumer> showAllConsumers()throws BillException;

List<Bill> getBillDetails(int consumerNum)throws BillException;


}
