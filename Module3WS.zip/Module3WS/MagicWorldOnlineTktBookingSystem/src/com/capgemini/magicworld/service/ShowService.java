package com.capgemini.magicworld.service;

import java.util.List;

import com.capgemini.magicworld.Exceptions.ShowException;
import com.capgemini.magicworld.dto.Show;




public interface ShowService {
	public List<Show> showDetails() throws ShowException ;
	public int avlSeats(String shwId) throws ShowException;
	public int bookTicket(String showid) throws ShowException;
	public List<Show> showReqDetails(String showid) throws ShowException ;
}
