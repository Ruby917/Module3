package com.capgemini.magicworld.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.magicworld.Exceptions.ShowException;
import com.capgemini.magicworld.dto.Show;
import com.capgemini.magicworld.service.ShowService;
import com.capgemini.magicworld.service.ShowServiceImpl;

/**
 * Author		:	Ruby Singh
 * Class Name	:	DonorImplDAO
 * Package		:	com.capgemini.electricity.controller
 * Date			:	14-Mar-2017
 */

@WebServlet("*.do")
public class ShowController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	ShowService showservice = null;
	private ShowController() throws ShowException{
		showservice = new ShowServiceImpl();
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			processRequest(req,resp);
		} catch (ShowException e) {
			e.printStackTrace();
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			processRequest(req,resp);
		} catch (ShowException e) {
			e.printStackTrace();
		}
	}


	private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, ShowException {
		String path = request.getServletPath();
		HttpSession session = request.getSession();
		if(path.equals("/show.do")){
			List<Show> myShow = new ArrayList<Show>();
			myShow = showservice.showDetails();
			session.setAttribute("list", myShow);
			RequestDispatcher dispatch = request.getRequestDispatcher("showDetails.jsp");
			dispatch.forward(request, response);
		}
		else if(path.equals("/book.do")){
			String shid = request.getQueryString();
			String showid = shid.substring(7,11);
			System.out.println(showid);
		   
		   List<Show> myShow = new ArrayList<Show>();
			myShow = showservice.showReqDetails(showid);
	        session.setAttribute("reqshow",myShow);
			
		   RequestDispatcher dispatch = request.getRequestDispatcher("bookNow.jsp");
		   dispatch.forward(request, response);
		}else if(path.equals("/sucess.do")){
			String shid = request.getQueryString();
			String showid = shid.substring(7,11);
			System.out.println(showid);
			
			int avalSeats = showservice.avlSeats(showid);
			   System.out.println(avalSeats);
			   request.setAttribute("alvseats", avalSeats);
			if(avalSeats>0){
				int status = showservice.bookTicket(showid);
				if(status==1){
					RequestDispatcher dispatch = request.getRequestDispatcher("sucess.jsp");
					dispatch.forward(request, response);
				}else{
					RequestDispatcher dispatch = request.getRequestDispatcher("error.jsp");
					dispatch.forward(request, response);

				}
				
			}else{
				RequestDispatcher dispatch = request.getRequestDispatcher("error.jsp");
				dispatch.forward(request, response);
			}
			
	}
	
	}
}

