package com.capgemini.magicworld.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.magicworld.Exceptions.ShowException;
import com.capgemini.magicworld.dto.Show;
import com.capgemini.magicworld.util.DBUtil;

/**
 * Author		:	Ruby Singh
 * Class Name	:	DonorImplDAO
 * Package		:	com.capgemini.electricity.dao
 * Date			:	14-Mar-2017
 */

public class ShowDAOImpl  implements ShowDAO{
	private DBUtil util;
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	public ShowDAOImpl() throws ShowException{
		util = new DBUtil();
	}
	
	@Override
	public List<Show> showDetails() throws ShowException {
		List<Show> myShow = new ArrayList<Show>();
		try {
			conn=util.getConnection();
			String query = "SELECT SHOWID,SHOWNAME,LOCATION,SHOWDATE,AVSEATS,PRICETICKET FROM SHOWDETAILS";
			pstmt = conn.prepareStatement(query);
			rs = pstmt.executeQuery();
			while(rs.next()){
			  Show show = new Show();
			  show.setShowId(rs.getString("SHOWID"));
			  show.setShowName(rs.getString("SHOWNAME"));
			  show.setLocation(rs.getString("LOCATION"));
			  show.setShowDate(rs.getDate("SHOWDATE"));
			  show.setAvlSeats(rs.getInt("AVSEATS"));
			  show.setTktPrice(rs.getDouble("PRICETICKET"));
			  myShow.add(show);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				if(rs!=null){
					rs.close();
				}
				if(pstmt!=null){
					pstmt.close();
				}
				if(conn!=null){
					conn.close();
				}
			} catch (SQLException e) {
				throw new ShowException("Database closing failed",e);
			}
		}
		return myShow;
	}
	
	public int bookTicket(String showname) throws ShowException{
		int status= 0;
		int avlseats = avlSeats(showid);
		try {
			conn=util.getConnection();
			String query = "UPDATE SHOWDETAILS SET AVSEATS=AVSEATS-? WHERE SHOWID=?";
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, showid);
			pstmt.setInt(2, avlseats);
			pstmt.executeUpdate();
			System.out.println(status);
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				if(pstmt!=null){
					pstmt.close();
				}
				if(conn!=null){
					conn.close();
				}
			} catch (SQLException e) {
				throw new ShowException("Database closing failed",e);
			}
		}
		return status;
	}
	
	
	
	
	public int avlSeats(String shwId) throws ShowException{
		int availseats = 0;
		try {
			conn=util.getConnection();
			String query = "SELECT AVSEATS FROM SHOWDETAILS WHERE SHOWID=?";
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1,shwId);
			rs = pstmt.executeQuery();
			while(rs.next()){
				availseats = rs.getInt("AVSEATS");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				if(rs!=null){
					rs.close();
				}
				if(pstmt!=null){
					pstmt.close();
				}
				if(conn!=null){
					conn.close();
				}
			} catch (SQLException e) {
				throw new ShowException("Database closing failed",e);
			}
		}
		System.out.println(availseats);
		return availseats;
	}

	@Override
	public Show showReqDetails(String shid) throws ShowException {
		Show show = null;
		try {
			conn=util.getConnection();
			String query = "SELECT SHOWNAME,AVSEATS,PRICETICKET FROM SHOWDETAILS WHERE SHOWID=?";
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1,shid);
			rs = pstmt.executeQuery();
			while(rs.next()){
			  show = new Show();
			  show.setShowName(rs.getString("SHOWNAME"));
			  show.setAvlSeats(rs.getInt("AVSEATS"));
			  show.setTktPrice(rs.getDouble("PRICETICKET"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				if(rs!=null){
					rs.close();
				}
				if(pstmt!=null){
					pstmt.close();
				}
				if(conn!=null){
					conn.close();
				}
			} catch (SQLException e) {
				throw new ShowException("Database closing failed",e);
			}
		}
		return show;
	}

}

			



