package com.capgemini.magicworld.dao;

import java.sql.SQLException;
import java.util.List;

import com.capgemini.magicworld.Exceptions.ShowException;
import com.capgemini.magicworld.dto.Show;


public interface ShowDAO {
	public List<Show> showDetails() throws ShowException ;
	public int avlSeats(String shwId) throws ShowException;
	public int bookTicket(String showname) throws ShowException;
	public Show showReqDetails(String showid) throws ShowException ;
}
