package com.capgemini.magicworld.service;

import java.util.List;
import java.util.regex.Pattern;

import com.capgemini.magicworld.Exceptions.ShowException;
import com.capgemini.magicworld.dao.ShowDAO;
import com.capgemini.magicworld.dao.ShowDAOImpl;
import com.capgemini.magicworld.dto.Show;


/**
 * Author		:	Ruby Singh
 * Class Name	:	EBillServiceImpl
 * Package		:	com.capgemini.electricity.service
 * Date			:	14-Mar-2017
 */



public class ShowServiceImpl implements ShowService{
	ShowDAO showdao = null;
	
	public ShowServiceImpl() throws ShowException{
		showdao = new ShowDAOImpl();
	}

	@Override
	public List<Show> showDetails() throws ShowException {
		return showdao.showDetails();
	}

	@Override
	public int avlSeats(String shwId) throws ShowException {
		return showdao.avlSeats(shwId);
	}

	@Override
	public int bookTicket(String showid) throws ShowException {
		return showdao.bookTicket(showid);
	}

	@Override
	public Show showReqDetails(String showid) throws ShowException {
		return showdao.showReqDetails(showid);
	}
	public void validateName(String patt,String name) throws ShowException{
		boolean value=Pattern.matches(patt,name);
		if(!value){
			throw new ShowException("Name should be in albhabets");
		}
			
		}
	public void validateMobileNumber(String patt,String name) throws ShowException{
		boolean value=Pattern.matches(patt,name);
		if(!value){
			throw new ShowException("Mobile Number should be of 10 digit");
		}
			
		}

}
