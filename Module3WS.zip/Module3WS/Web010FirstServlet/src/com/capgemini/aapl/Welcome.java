package com.capgemini.aapl;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/welcome")
public class Welcome extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private int visits = 0;
	
	
	
	@Override
	public void destroy() {
		System.out.println("In destroy()");
		super.destroy();
	}



	@Override
	public void init() throws ServletException {
		super.init();
		System.out.println("In init()");
	}



	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("method type: "+request.getMethod());
		System.out.println("Message on console"+request.getServletPath());
		
		PrintWriter out = response.getWriter();
		out.write("Welcome..."+(++visits));
	}

}
