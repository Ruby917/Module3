package com.cg.empManagement.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.empManagement.dto.Employee;
import com.cg.empManagement.exception.EmployeeException;
import com.cg.empManagement.service.EmployeeService;
import com.cg.empManagement.service.EmployeeServiceImpl;

@WebServlet("*.do")
public class EmpController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	EmployeeService empservice = null;
     
    public EmpController() throws EmployeeException {
    	empservice = new EmployeeServiceImpl();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			processRequest(request, response);
		} catch (EmployeeException e) {
			e.printStackTrace();
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			processRequest(request, response);
		} catch (EmployeeException e) {
			e.printStackTrace();
		}
	}

	private void processRequest(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException, EmployeeException{
		String path = request.getServletPath();
		System.out.println(path);
		if(path.equals("/empl.do")){
			RequestDispatcher dispatch = request.getRequestDispatcher("addemployee.jsp");
			dispatch.forward(request, response);
		}
		if(path.equals("/empladd.do")){
			Employee emp = new Employee();
			String name = request.getParameter("name");
			String qualification = request.getParameter("qual");
			int salary = Integer.parseInt(request.getParameter("empsal"));
			
			emp.setEmpName(name);
			emp.setEmpQualification(qualification);
			emp.setSalary(salary);

			try {
				int empid = empservice.addEmployee(emp);
				System.out.println(empid);
				request.setAttribute("id",empid);
				RequestDispatcher dispatch = request.getRequestDispatcher("welcome.jsp");
				dispatch.forward(request, response);
			} catch (EmployeeException e) {
				System.out.println("controller error");
				e.printStackTrace();
			}
		}
		else if(path.equals("/showall.do")){
			List<Employee> mylist = new ArrayList<Employee>();
			try {
				mylist = empservice.showAll();
				System.out.println(mylist);
			} catch (EmployeeException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
	       request.setAttribute("data", mylist);
	       RequestDispatcher dispatch = request.getRequestDispatcher("showall.jsp");
			dispatch.forward(request, response);
		}else if(path.equals("/update.do")){
			System.out.println("Update..");
			String empid = request.getQueryString();
			String emid = empid.substring(3,7);
			int eid = Integer.parseInt(emid);
			System.out.println(eid);
			Employee eData = empservice.getEmployee(eid);
			System.out.println(eData);
			request.setAttribute("empdata", eData);
	   	    RequestDispatcher dispatch = request.getRequestDispatcher("update.jsp");
			dispatch.forward(request, response);
		}else if(path.equals("/updatedata.do")){
			int eid = Integer.parseInt(request.getParameter("id"));
			String name = request.getParameter("name");
			String qualification = request.getParameter("qual");
			int salary = Integer.parseInt(request.getParameter("sal"));
			
			Employee e = new Employee();
			e.setEmpId(eid);
			e.setEmpName(name);
			e.setEmpQualification(qualification);
			e.setSalary(salary);
		
			empservice.updateEmployee(e);
			List<Employee> list = new ArrayList<Employee>();
			try {
				list = empservice.showAll();
				System.out.println(list);
			} catch (EmployeeException em) {
				em.printStackTrace();
			} catch (SQLException em) {
				em.printStackTrace();
			}
	       request.setAttribute("data", list);
			RequestDispatcher dispatch = request.getRequestDispatcher("showall.jsp");
			dispatch.forward(request, response);
		}else if(path.equals("/delete.do")){
			String empid = request.getQueryString();
			String emid = empid.substring(3, 7);
			int eid = Integer.parseInt(emid);
			empservice.deleteEmployee(eid);
			List<Employee> list = new ArrayList<Employee>();
			try {
				list = empservice.showAll();
				System.out.println(list);
			} catch (EmployeeException em) {
				em.printStackTrace();
			} catch (SQLException em) {
				em.printStackTrace();
			}
	       request.setAttribute("data", list);
			RequestDispatcher dispatch = request.getRequestDispatcher("showall.jsp");
			dispatch.forward(request, response);
		}
		
	}
}
