package com.cg.empManagement.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;




import com.cg.empManagement.dto.Employee;
import com.cg.empManagement.exception.EmployeeException;
import com.cg.empManagement.util.DBUtil;



public class EmployeeDaoImpl implements EmployeeDao{
	private DBUtil util;
	Connection conn = null;
	PreparedStatement pstmt = null;
	
	public EmployeeDaoImpl() throws EmployeeException {
		util = new DBUtil();
	}
	
	@Override
	public int addEmployee(Employee emp) throws EmployeeException {
		int msg = 0;
		try {
			int emp_id = getEmployeeId();
			conn = util.getConnection();
			String query="INSERT INTO EMPL VALUES(?,?,?,?)";
			pstmt=conn.prepareStatement(query);
			pstmt.setInt(1,emp_id);
			pstmt.setString(2, emp.getEmpName());
			pstmt.setString(3, emp.getEmpQualification());
			pstmt.setInt(4, emp.getSalary());
			int status=pstmt.executeUpdate();
			if(status==1){
				msg = emp_id;
				System.out.println("data inserted");
			}
			else{
				System.out.println("data not inserted");
			}
		} catch (SQLException e) {
			System.out.println("not inserted");
			e.printStackTrace();
		}finally{
			try {
				if(pstmt!=null){
					pstmt.close();
				}
				if(conn!=null){
					conn.close();
				}
			} catch (SQLException e) {
				throw new EmployeeException("Database closing failed");
			}
		}
		return msg;
	}

	@Override
	public List<Employee> showAll() throws EmployeeException, SQLException {
		List<Employee> myEmp = new ArrayList<Employee>();
		conn=util.getConnection();
		String query = "SELECT EMP_ID,EMP_NAME,EMP_QUAL,EMP_SAL FROM EMPL";
		try {
			pstmt = conn.prepareStatement(query);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()){
			  Employee e = new Employee();
			  e.setEmpId(rs.getInt("emp_id"));
			  e.setEmpName(rs.getString("emp_name"));
			  e.setEmpQualification(rs.getString("emp_qual"));
			  e.setSalary(rs.getInt("emp_sal"));
			  myEmp.add(e);
			}
			rs.close(); 
		} catch (SQLException e) {
			e.printStackTrace();
			throw new EmployeeException("problem in show");
			
		}finally{
			try {
				if(pstmt!=null){
					pstmt.close();
				}
				if(conn!=null){
					conn.close();
				}
			} catch (SQLException e) {
				throw new EmployeeException("Database closing failed");
			}
		}
		return myEmp;
	}
	public int getEmployeeId() throws EmployeeException{
		int emp_id = 0;
		try {
			conn = util.getConnection();
			String query="SELECT EMP_SEQ.NEXTVAL FROM DUAL";
			pstmt= conn.prepareStatement(query);
			ResultSet res = pstmt.executeQuery();
			while(res.next()){
				emp_id = res.getInt(1);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new EmployeeException("sequence note generated");
		}finally{
			try {
				if(pstmt!=null){
					pstmt.close();
				}
				if(conn!=null){
					conn.close();
				}
			} catch (SQLException e) {
				throw new EmployeeException("Database closing failed");
			}
		}
		return emp_id;
		
	}

	@Override
	public int updateEmployee(Employee emp) throws EmployeeException {
		try {
			conn=util.getConnection();
			String query = "UPDATE EMPL SET EMP_NAME=?,EMP_QUAL=?,EMP_SAL=? WHERE EMP_ID=?";
			pstmt= conn.prepareStatement(query);
			pstmt.setString(1,emp.getEmpName());
			pstmt.setString(2, emp.getEmpQualification());
			pstmt.setInt(3,emp.getSalary());
			pstmt.setInt(4,emp.getEmpId());
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				if(pstmt!=null){
					pstmt.close();
				}
				if(conn!=null){
					conn.close();
				}
			} catch (SQLException e) {
				throw new EmployeeException("Database closing failed");
			}
		}

		return 0;
	}

	@Override
	public int deleteEmployee(int empid) throws EmployeeException{
		int rec = 0;
		try{
		conn=util.getConnection();
		String query = "DELETE FROM EMPL WHERE EMP_ID=?";
		pstmt= conn.prepareStatement(query);
		pstmt.setInt(1, empid);
		rec = pstmt.executeUpdate();
		if(rec>0){
			return 1;
		}
	} catch (SQLException e) {
		System.out.println(e);
		
	} finally {
		try {
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			System.out.println(e);
			throw new EmployeeException("Data Not Removed");
		}

	}
		return 0;
	}

	@Override
	public Employee getEmployee(int id) throws EmployeeException {
		String query = "SELECT EMP_ID,EMP_NAME,EMP_QUAL,EMP_SAL FROM EMPL WHERE EMP_ID=?";
		Employee emp = new Employee();
		try {
			conn = util.getConnection();
			pstmt= conn.prepareStatement(query);
			pstmt.setInt(1,id);
			ResultSet res = pstmt.executeQuery();
			while(res.next()){
				emp.setEmpId(res.getInt(1));
				emp.setEmpName(res.getString(2));
				emp.setEmpQualification(res.getString(3));
				emp.setSalary(res.getInt(4));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				System.out.println(e);
				throw new EmployeeException("Data Not Removed");
			}
		}
		return emp;
	}

	}
