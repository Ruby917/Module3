package com.cg.empManagement.dao;

import java.sql.SQLException;
import java.util.List;

import com.cg.empManagement.dto.Employee;
import com.cg.empManagement.exception.EmployeeException;


public interface EmployeeDao {
	public int addEmployee(Employee emp) throws EmployeeException;
	public List<Employee> showAll() throws EmployeeException, SQLException;
	public Employee getEmployee(int id) throws EmployeeException;
	public int updateEmployee(Employee e) throws EmployeeException;
    public int deleteEmployee(int empid) throws EmployeeException;
}
