package com.cg.empManagement.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.empManagement.dao.EmployeeDao;
import com.cg.empManagement.dao.EmployeeDaoImpl;
import com.cg.empManagement.dto.Employee;
import com.cg.empManagement.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService{
	EmployeeDao empdao = null;
	
	public EmployeeServiceImpl() throws EmployeeException {
		empdao = new EmployeeDaoImpl();
	}

	@Override
	public int addEmployee(Employee emp) throws EmployeeException {
		return empdao.addEmployee(emp);
	}

	@Override
	public List<Employee> showAll() throws EmployeeException, SQLException {
		return empdao.showAll();
	}

	@Override
	public Employee getEmployee(int id) throws EmployeeException {
		return empdao.getEmployee(id);
	}

	@Override
	public int updateEmployee(Employee e) throws EmployeeException {
		return empdao.updateEmployee(e);
	}

	@Override
	public int deleteEmployee(int empid) throws EmployeeException {
		return empdao.deleteEmployee(empid);
	}
}
