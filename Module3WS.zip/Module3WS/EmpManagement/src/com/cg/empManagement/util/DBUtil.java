package com.cg.empManagement.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.empManagement.exception.EmployeeException;


public class DBUtil {
	private DataSource datasource;

	public DBUtil() throws EmployeeException {
		try {
			Context ctx = new InitialContext(); //get reference to remote JNDI
			datasource  = (DataSource) ctx.lookup("java:/OracleDS");
		} catch (NamingException e) {
			e.printStackTrace();
			throw new EmployeeException("failed to get JNDI Context");
		}
	}
	
	public Connection getConnection() throws SQLException{
		return datasource.getConnection();
	}
	
	
}

