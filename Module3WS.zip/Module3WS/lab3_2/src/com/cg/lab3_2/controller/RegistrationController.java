package com.cg.lab3_2.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.lab3_2.dto.UserDto;
import com.cg.lab3_2.exception.RegistrationException;
import com.cg.lab3_2.service.IRegisterService;
import com.cg.lab3_2.service.RegisterServiceImpl;

@WebServlet("/registration")
public class RegistrationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private IRegisterService registerservice = null; 
	
    public RegistrationController() throws RegistrationException {
    	registerservice = new RegisterServiceImpl();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	private void processRequest(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		try {
			String fname = request.getParameter("fname");
			String lname = request.getParameter("lname");
			String password = request.getParameter("pwd");
			String genderstr =  request.getParameter("gender");
			String skill = request.getParameter("skill");
			String city = request.getParameter("city");
			char gender;
			if(genderstr.equals("M")){
				gender = 'M';
			}else{
				gender = 'F';
			}
			
			UserDto userdto = new UserDto();
			userdto.setFirstname(fname);
			userdto.setLastname(lname);
			userdto.setPassword(password);
			userdto.setGender(gender);
			userdto.setSkill(skill);
			userdto.setCity(city);
			System.out.println("1");
			int status = registerservice.addRegistrationDetails(userdto);
			if(status==1){
				response.sendRedirect("sucess.html");
			}
			else{
				response.sendRedirect("fail.html");
			}
		} catch (RegistrationException e) {
			e.printStackTrace();
		}
	}
}
