package com.cg.lab3_2.service;

import com.cg.lab3_2.dao.IRegisterDao;
import com.cg.lab3_2.dao.RegisterDaoImpl;
import com.cg.lab3_2.dto.UserDto;
import com.cg.lab3_2.exception.RegistrationException;

public class RegisterServiceImpl implements IRegisterService {
	IRegisterDao registerdao = null;
	
	public RegisterServiceImpl() throws RegistrationException {
		registerdao = new RegisterDaoImpl();
	}

	@Override
	public int addRegistrationDetails(UserDto user) throws RegistrationException {
		return registerdao.addRegistrationDetails(user);	
	}

}
