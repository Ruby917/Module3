package com.cg.lab3_2.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cg.lab3_2.dto.UserDto;
import com.cg.lab3_2.exception.RegistrationException;
import com.cg.lab3_2.util.DBUtil;

public class RegisterDaoImpl implements IRegisterDao{
	private DBUtil util;
	Connection conn = null;
	PreparedStatement pstmt = null;

	public RegisterDaoImpl() throws RegistrationException {
		util = new DBUtil();
	}

	@Override
	public int addRegistrationDetails(UserDto user) throws RegistrationException {
		int status=0;
		try{
		conn = util.getConnection();
		String query="INSERT INTO REGISTEREDUSERS VALUES(?,?,?,?,?,?)";
		pstmt=conn.prepareStatement(query);
		pstmt.setString(1,user.getFirstname());
		pstmt.setString(2, user.getLastname());
		pstmt.setString(3, user.getPassword());
		pstmt.setString(4, String.valueOf(user.getGender()));
		pstmt.setString(5, user.getSkill());
		pstmt.setString(6, user.getCity());
		status=pstmt.executeUpdate();
		if(status==1){
			System.out.println("data inserted");
		}
		else{
			System.out.println("data not inserted");
		}
	} catch (SQLException e) {
		System.out.println("not inserted");
		e.printStackTrace();
	}finally{
		try {
			if(pstmt!=null){
				pstmt.close();
			}
			if(conn!=null){
				conn.close();
			}
		} catch (SQLException e) {
			throw new RegistrationException("Database closing failed");
		}
	}
		return status;
		
	}

}
