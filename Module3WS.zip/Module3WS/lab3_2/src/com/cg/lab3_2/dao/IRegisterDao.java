package com.cg.lab3_2.dao;

import com.cg.lab3_2.dto.UserDto;
import com.cg.lab3_2.exception.RegistrationException;

public interface IRegisterDao {
	public int addRegistrationDetails(UserDto user) throws RegistrationException;

}
