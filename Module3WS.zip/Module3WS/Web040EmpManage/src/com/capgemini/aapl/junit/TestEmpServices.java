package com.capgemini.aapl.junit;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.aapl.entities.Employee;
import com.capgemini.aapl.exceptions.EmpException;
import com.capgemini.aapl.services.EmpServices;
import com.capgemini.aapl.services.EmpServicesImpl;

public class TestEmpServices {
	private static EmpServices services;

	@Before
	public void setUp() throws Exception {
		services = new EmpServicesImpl();
	}

	@After
	public void tearDown() throws Exception {
		services = null;
	}

	@Test
	public void test() {
		try {
			Employee expectedEmp = new Employee(7500,"RUBY",2000.0F);
			Employee actualEmp;
			actualEmp = services.getEmpDetails(7500);
			assertEquals(expectedEmp,actualEmp);
		} catch (EmpException e) {
 			e.printStackTrace();
		}
		
	}
	public void testGetExceptionOnWrongEmpNo(){
		try {
			Employee actualEmp = services.getEmpDetails(7500);
		} catch (EmpException e) {
			e.printStackTrace();
		}

		
	}

}
