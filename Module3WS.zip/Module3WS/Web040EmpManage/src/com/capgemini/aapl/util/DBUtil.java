package com.capgemini.aapl.util;

import java.sql.Connection;
import java.sql.SQLException;
import oracle.jdbc.pool.OracleDataSource;

public class DBUtil {
	
	private OracleDataSource dataSource;
	public DBUtil(){
		
		try {
		  
			dataSource = new OracleDataSource();
			dataSource.setURL("jdbc:oracle:thin:@10.125.6.62:1521:orcl11g");
			dataSource.setUser("labg104trg26");
			dataSource.setPassword("labg104oracle");
			dataSource.setDriverType("oracle");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	public Connection getConnection() throws SQLException{
		return dataSource.getConnection();
	}
	@Override
	protected void finalize() throws Throwable {
		dataSource.close();
		super.finalize();
	}

}
