package com.capgemini.aapl.services;

import com.capgemini.aapl.daos.EmpDao;
import com.capgemini.aapl.daos.EmpDaoImpl;
import com.capgemini.aapl.entities.Employee;
import com.capgemini.aapl.exceptions.EmpException;

public class EmpServicesImpl implements EmpServices {
	EmpDao empdao = null;

	public EmpServicesImpl() {
		empdao = new EmpDaoImpl();
	}

	@Override
	public Employee getEmpDetails(int empNo) throws EmpException {
		
		return empdao.getEmpDetails(empNo);
	}

}
