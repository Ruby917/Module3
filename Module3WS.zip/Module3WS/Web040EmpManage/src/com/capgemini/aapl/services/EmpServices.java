package com.capgemini.aapl.services;

import com.capgemini.aapl.entities.Employee;
import com.capgemini.aapl.exceptions.EmpException;

public interface EmpServices {
	Employee getEmpDetails(int empNo) throws EmpException;


}
