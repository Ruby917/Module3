package com.capgemini.aapl.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.aapl.entities.Employee;
import com.capgemini.aapl.exceptions.EmpException;
import com.capgemini.aapl.services.EmpServices;
import com.capgemini.aapl.services.EmpServicesImpl;

@WebServlet("*.do")
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private EmpServices services;
	private RequestDispatcher dispatch;
	private String nextJsp;
	
	public void init(ServletConfig config) throws ServletException {
			services = new EmpServicesImpl();
	}

	private void processRequest(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		String command = request.getServletPath();
		System.out.println(command);
		switch(command){
		case "/acceptEmpNo.do" :{
			
			nextJsp ="/acceptEmpNo.jsp";
			break;
		}
		case "/showEmpDetails.do" :{
			
			try {
				String empNostr = request.getParameter("empNo");
				int empNo = Integer.parseInt(empNostr);
				Employee emp = services.getEmpDetails(empNo);
				request.setAttribute("emp", emp);
				
				nextJsp ="/showEmpDetails.jsp";
				System.out.println(empNo);
				break;
			} catch (NumberFormatException e) {
				request.setAttribute("errorMsg","Wrong empNo input");
				nextJsp = "/error.jsp";
			} catch (EmpException e) {
				request.setAttribute("errorMsg","EmpNo does not exist");
				nextJsp = "/error.jsp";
			}
		}
		
		}
		dispatch = request.getRequestDispatcher(nextJsp);
		dispatch.forward(request, response);
		
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}
	public void destroy() {
		
	}

}
