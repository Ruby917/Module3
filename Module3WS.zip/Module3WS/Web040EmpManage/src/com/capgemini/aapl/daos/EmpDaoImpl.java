package com.capgemini.aapl.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.aapl.entities.Employee;
import com.capgemini.aapl.exceptions.EmpException;
import com.capgemini.aapl.util.DBUtil;

public class EmpDaoImpl implements EmpDao{
	private DBUtil util;

	public EmpDaoImpl() {
		util = new DBUtil();
	}

	@Override
	public Employee getEmpDetails(int empNo) throws EmpException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String qry = "SELECT EMPNO,EMPNM,EMPSAL FROM EMP WHERE EMPNO = ?";
		try {
			conn = util.getConnection();
			pstmt = conn.prepareStatement(qry);
			pstmt.setInt(1, empNo);
			rs = pstmt.executeQuery();
			if(rs.next()){
				String empName = rs.getString("EMPNM");
				int empSal = rs.getInt("EMPSAL");
				
				
				Employee empl = new Employee(empNo,empName,empSal);
				return empl;
			}else{
				throw new EmpException("EmpId is invalid");
			}
		} catch (SQLException e) {
			throw new EmpException("Database not connected",e);
		}finally{
			try {
				if(rs!=null){
						rs.close();
				}
				if(pstmt!=null){
					pstmt.close();
				}
				if(conn!=null){
					conn.close();
				}
			} catch (SQLException e) {
				throw new EmpException("Database closing failed",e);
			}
		}
	}

	

}
