package com.capgemini.aapl.daos;

import com.capgemini.aapl.entities.Employee;
import com.capgemini.aapl.exceptions.EmpException;

public interface EmpDao {
	Employee getEmpDetails(int empNo) throws EmpException;

}
