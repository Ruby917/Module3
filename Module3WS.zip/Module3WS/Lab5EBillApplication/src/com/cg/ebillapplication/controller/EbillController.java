package com.cg.ebillapplication.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.ebillapplication.dto.BillDTO;
import com.cg.ebillapplication.dto.ConsumerDto;
import com.cg.ebillapplication.exception.EbillException;
import com.cg.ebillapplication.service.EBillService;
import com.cg.ebillapplication.service.EBillServiceImpl;


@WebServlet("*.do")
public class EbillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	EBillService billservice = null;
	
    public EbillController() throws EbillException {
		billservice = new EBillServiceImpl();    
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			processRequest(request,response);
		} catch (EbillException e) {
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			processRequest(request,response);
		} catch (EbillException e) {
			e.printStackTrace();
		}
	}

	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, EbillException {
		String path = request.getServletPath();
		if(path.equals("/login.do")){
			String userName = request.getParameter("uname");
			String password = request.getParameter("pwd");
			String status = isUserAuthenticated(userName, password);
			if(status.equals("Sucess")){
				RequestDispatcher dispatch = request.getRequestDispatcher("User_Info.html");
				dispatch.forward(request, response);
			}else{
				RequestDispatcher dispatch = request.getRequestDispatcher("error.jsp");
				dispatch.forward(request, response);
			}
		}else if(path.equals("/calculatebill.do")){
			int cust_no = Integer.parseInt(request.getParameter("cno"));
			/*
			
			String patt="[1-9]{6}";
			String cuno = String.valueOf(cust_no);
			billservice.validateConsumerNo(patt, cuno);
			*/
			
			
			double last_month_reading = Double.parseDouble(request.getParameter("lmr"));
			double curr_month_reading = Double.parseDouble(request.getParameter("cmr"));
			double unitCon = calUnitConsumed(last_month_reading,curr_month_reading);
			double netAmt = calNetAmount(last_month_reading, curr_month_reading);
			
			if(curr_month_reading<=last_month_reading){
				request.setAttribute("cno",cust_no);
				request.setAttribute("uc", unitCon);
				request.setAttribute("na", netAmt);
				
				List<Integer> l = new ArrayList<Integer>();
				l = billservice.checkConsumerNumber();
				if(l.contains(cust_no)){
					BillDTO bill = new BillDTO();
					ConsumerDto con = new ConsumerDto();
					
					con.setCustomerNo(cust_no);
					bill.setCurrentMonthReading(curr_month_reading);
					bill.setUnitConsumed(unitCon);
					bill.setNetAmount(netAmt);
					
				    billservice.addBillDetails(con,bill);
					
				    String cn = billservice.getCunsumername(cust_no);
				    request.setAttribute("cname",cn);
				 RequestDispatcher dispatch = request.getRequestDispatcher("InfoView.jsp");
	  			dispatch.forward(request, response);
					
				}else{
					 RequestDispatcher dispatch = request.getRequestDispatcher("errorview.jsp");
						dispatch.forward(request, response);
				}
			}else{
				PrintWriter write = response.getWriter();
				write.print("<h2>Current Month meter reading cannot be less than Last Month meter reading</h2>");
				RequestDispatcher dispatch = request.getRequestDispatcher("User_Info.html");
	  			dispatch.forward(request, response);
			}
			
			
		}
	}	
	private double calUnitConsumed(double last_month_reading,double curr_month_reading){
		double unitsConsumed = last_month_reading - curr_month_reading;
		return unitsConsumed;
	}
	private double calNetAmount(double LMR,double CMR){
		int fixedCharge = 100;
		double unitconsumed = calUnitConsumed(LMR, CMR);
		double netAmount = unitconsumed * 1.15 + fixedCharge;
		return netAmount;
	}
	
	private String isUserAuthenticated(String userName, String password){
		if(userName.equals("rima") && password.equals("rima")){
			return "Sucess";
		}else{
			return "failed";
		}
	}
}
