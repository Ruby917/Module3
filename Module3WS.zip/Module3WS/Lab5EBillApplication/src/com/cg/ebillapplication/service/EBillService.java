package com.cg.ebillapplication.service;

import java.util.List;

import com.cg.ebillapplication.dto.BillDTO;
import com.cg.ebillapplication.dto.ConsumerDto;
import com.cg.ebillapplication.exception.EbillException;

public interface EBillService {
	public int addBillDetails(ConsumerDto con, BillDTO bill) throws EbillException;
	public String getCunsumername(int cno) throws EbillException;
	public List<Integer> checkConsumerNumber() throws EbillException;
	//public void validateConsumerNo(String patt,String name) throws EbillException;
}
