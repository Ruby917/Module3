package com.cg.ebillapplication.dao;

import java.util.List;

import com.cg.ebillapplication.dto.BillDTO;
import com.cg.ebillapplication.dto.ConsumerDto;
import com.cg.ebillapplication.exception.EbillException;

public interface EBillDAO {
	public int addBillDetails(ConsumerDto con,BillDTO bill) throws EbillException;
	public String getCunsumername(int cno) throws EbillException;
	public List<Integer> checkConsumerNumber() throws EbillException;

}
