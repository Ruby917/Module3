package com.capgemini.aapl.services;

import com.capgemini.aapl.daos.UserMasterDao;
import com.capgemini.aapl.daos.UserMasterDaoImpl;
import com.capgemini.aapl.entities.User;
import com.capgemini.aapl.exceptions.UserException;

public class UserMasterServicesImpl implements UserMasterServices{
	private UserMasterDao dao;

	
	public UserMasterServicesImpl() throws UserException{
		dao = new UserMasterDaoImpl();
	}
	
	@Override
	public User getUserDetails(String userName) throws UserException {
		return dao.getUserDetails(userName);
	}

	@Override
	public boolean isUserAuthenticated(String userName, String password) throws UserException {
		User user = dao.getUserDetails(userName);
		if(password.equals(user.getPassword())){
			return true;
		}else{
			return false;
		}
	}

}
