package com.capgemini.aapl.loginservlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.aapl.entities.User;
import com.capgemini.aapl.exceptions.UserException;
import com.capgemini.aapl.services.UserMasterServices;
import com.capgemini.aapl.services.UserMasterServicesImpl;

@WebServlet("*.do")
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String msg = null;

	
	private UserMasterServices services;
	private RequestDispatcher dispatch;
	private String nextJsp;
	ServletContext ctx = null;
	
	public void init() throws ServletException {
	    ctx = super.getServletContext();
		services = (UserMasterServices) ctx.getAttribute("services");
	}

	private void processRequest(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		String command = request.getServletPath();
		ctx.log(command);
		switch(command){
		case "/Login.do" :{
			
			nextJsp ="/Login.jsp";
			break;
		}
		case "/authenticate.do" :{
			
			String userName = request.getParameter("userId");
			String password = request.getParameter("pwd");
			try {
				boolean isAuthenticated  = services.isUserAuthenticated(userName, password);
				if(isAuthenticated){
					User user = services.getUserDetails(userName);
					HttpSession session = request.getSession(true);
					System.out.println(session.getId());
					session.setAttribute("user", user);
					//System.out.println("yes");
					nextJsp = "/mainManu.jsp";
					
				}else{
					//System.out.println("No");
					msg = "Wrong Credentials. Enter Again";
					request.setAttribute("errorMsg", msg);
					nextJsp = "/Login.jsp";
				}
			} catch (UserException e) {
				//e.printStackTrace();
				msg = "User name does not exist";
				request.setAttribute("errorMsg", msg);
				ctx.log(e.getMessage());
				nextJsp = "/error.jsp";
			}
			break;
							}
		case "/logout.do" :{
			HttpSession session = request.getSession(false);
			session.invalidate();
			nextJsp = "/Login.jsp";
			break;}
		
				}
		dispatch = request.getRequestDispatcher(nextJsp);
		dispatch.forward(request, response);

	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}
	public void destroy() {
		
	}

}
