package com.capgemini.aapl.loginservlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.aapl.entities.User;
import com.capgemini.aapl.exceptions.UserException;
import com.capgemini.aapl.services.UserMasterServices;
import com.capgemini.aapl.services.UserMasterServicesImpl;

@WebServlet("/authenticate")
public class Authenticate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserMasterServices services;
	ServletContext ctx = null;

	public void init() throws ServletException {
	    ctx = super.getServletContext();
		try {
			services = new UserMasterServicesImpl();
		} catch (UserException e) {
			RequestDispatcher dispatch = ctx.getRequestDispatcher("/error.jsp");
			ctx.log(e.getMessage());
		}
	}

	public void destroy() {
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse resp) throws ServletException, IOException{
	String userName = request.getParameter("userId");
	String password = request.getParameter("pwd");
	RequestDispatcher dispatcher = null;
	String nextJsp = null;
	String msg = null;
	try {
		boolean isAuthenticated  = services.isUserAuthenticated(userName, password);
		if(isAuthenticated){
			nextJsp = "/mainManu.jsp";
			
		}else{
			//System.out.println("No");
			msg = "Wrong Credentials. Enter Again";
			request.setAttribute("errorMsg", msg);
			nextJsp = "/Login.jsp";
		}
	} catch (UserException e) {
		//e.printStackTrace();
		msg = "User name does not exist";
		request.setAttribute("errorMsg", msg);
		nextJsp = "/error.jsp";
	}
	
	dispatcher = request.getRequestDispatcher(nextJsp);
	dispatcher.forward(request, resp);
	
	}
	
}
