package com.capgemini.aapl.listeners;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import com.capgemini.aapl.exceptions.UserException;
import com.capgemini.aapl.services.UserMasterServices;
import com.capgemini.aapl.services.UserMasterServicesImpl;

@WebListener
public class ProcureServiceListner implements ServletContextListener {
	private UserMasterServices services;
	private ServletContext ctx = null;

    public void contextInitialized(ServletContextEvent event)  { 
    	ctx = event.getServletContext();
    	try {
			services = new UserMasterServicesImpl();
			ctx.setAttribute("services", services);
		} catch (UserException e) {
			ctx.log(e.getMessage());
		}
    	       
    }

    public void contextDestroyed(ServletContextEvent arg0)  { 

    }

	
}
