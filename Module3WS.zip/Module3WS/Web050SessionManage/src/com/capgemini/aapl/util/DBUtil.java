package com.capgemini.aapl.util;

import java.sql.Connection;
import java.sql.SQLException;
import oracle.jdbc.pool.OracleDataSource;

public class DBUtil {
	//private Properties props;
	private OracleDataSource dataSource;
	public DBUtil(){
		//props = new Properties();
		//InputStream in = null;
		try {
		   /* in = new FileInputStream("D:\\MODULE_3\\Module3WS\\Web020LoginSimple\\src\\oracle.properties");
			props.load(in);
			
			dataSource = new OracleDataSource();
			dataSource.setURL(props.getProperty("url"));
			dataSource.setUser(props.getProperty("username"));
			dataSource.setPassword(props.getProperty("password"));
			dataSource.setDriverType("oracle");*/
			
			dataSource = new OracleDataSource();
			dataSource.setURL("jdbc:oracle:thin:@10.125.6.62:1521:orcl11g");
			dataSource.setUser("labg104trg26");
			dataSource.setPassword("labg104oracle");
			dataSource.setDriverType("oracle");
		} catch (SQLException e) {
			e.printStackTrace();
		}/*finally{
			try {
				in.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}*/
		
	}
	public Connection getConnection() throws SQLException{
		return dataSource.getConnection();
	}
	@Override
	protected void finalize() throws Throwable {
		dataSource.close();
		super.finalize();
	}

}
