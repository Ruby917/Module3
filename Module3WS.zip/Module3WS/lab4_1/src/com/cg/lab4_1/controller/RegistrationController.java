package com.cg.lab4_1.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.lab4_1.dto.UserDto;
import com.cg.lab4_1.exception.RegistrationException;
import com.cg.lab4_1.service.IRegisterService;
import com.cg.lab4_1.service.RegisterServiceImpl;

@WebServlet("*.do")
public class RegistrationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private IRegisterService registerservice = null; 
	
    public RegistrationController() throws RegistrationException {
    	registerservice = new RegisterServiceImpl();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	private void processRequest(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		String path = request.getServletPath();
		if(path.equals("/registration.do")){
			try {
				String fname = request.getParameter("fname");
				String lname = request.getParameter("lname");
				String password = request.getParameter("pwd");
				String genderstr =  request.getParameter("gender");
				String skill = request.getParameter("skill");
				String city = request.getParameter("city");
				char gender = genderstr.charAt(0);
				UserDto userdto = new UserDto();
				userdto.setFirstname(fname);
				userdto.setLastname(lname);
				userdto.setPassword(password);
				userdto.setGender(gender);
				userdto.setSkill(skill);
				userdto.setCity(city);
				System.out.println("1");
				int status = registerservice.addRegistrationDetails(userdto);
				if(status==1){
					response.sendRedirect("sucess.html");
				}
				else{
					response.sendRedirect("fail.html");
				}
			} catch (RegistrationException e) {
				e.printStackTrace();
			}
		}else if(path.equals("/showall.do")){
			List<UserDto> mylist = new ArrayList<UserDto>();
			try {
				mylist = registerservice.showAll();
				System.out.println(mylist);
			} catch (RegistrationException e) {
				e.printStackTrace();
			}
	       request.setAttribute("data", mylist);
	       RequestDispatcher dispatch = request.getRequestDispatcher("showall.jsp");
			dispatch.forward(request, response);
		}
		
		
		
	}
}
