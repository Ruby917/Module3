package com.cg.lab4_1.dto;

public class UserDto {
	private String firstname;
	private String lastname;
	private String password;
	private char gender;
	private String skill;
	private String city;
	
	public UserDto() {
	}

	public UserDto(String firstname, String lastname, String password,
			char gender, String skill, String city) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.password = password;
		this.gender = gender;
		this.skill = skill;
		this.city = city;
	}

	@Override
	public String toString() {
		return "UserDto [firstname=" + firstname + ", lastname=" + lastname
				+ ", password=" + password + ", gender=" + gender + ", skill="
				+ skill + ", city=" + city + "]";
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}

	public String getSkill() {
		return skill;
	}

	public void setSkill(String skill) {
		this.skill = skill;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	
}
