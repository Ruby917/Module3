package com.cg.lab4_1.service;

import java.util.List;

import com.cg.lab4_1.dto.UserDto;
import com.cg.lab4_1.exception.RegistrationException;

public interface IRegisterService {
	public int addRegistrationDetails(UserDto user) throws RegistrationException;
	public List<UserDto> showAll() throws RegistrationException;
}
