package com.cg.lab4_1.service;

import java.util.List;

import com.cg.lab4_1.dao.IRegisterDao;
import com.cg.lab4_1.dao.RegisterDaoImpl;
import com.cg.lab4_1.dto.UserDto;
import com.cg.lab4_1.exception.RegistrationException;

public class RegisterServiceImpl implements IRegisterService {
	IRegisterDao registerdao = null;
	
	public RegisterServiceImpl() throws RegistrationException {
		registerdao = new RegisterDaoImpl();
	}

	@Override
	public int addRegistrationDetails(UserDto user) throws RegistrationException {
		return registerdao.addRegistrationDetails(user);	
	}

	@Override
	public List<UserDto> showAll() throws RegistrationException {
		return registerdao.showAll();
	}

}
