package com.cg.lab4_1.dao;

import java.util.List;

import com.cg.lab4_1.dto.UserDto;
import com.cg.lab4_1.exception.RegistrationException;

public interface IRegisterDao {
	public int addRegistrationDetails(UserDto user) throws RegistrationException;
	public List<UserDto> showAll() throws RegistrationException;
}
