package com.cg.lab4_1.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.lab4_1.dto.UserDto;
import com.cg.lab4_1.exception.RegistrationException;
import com.cg.lab4_1.util.DBUtil;

public class RegisterDaoImpl implements IRegisterDao{
	private DBUtil util;
	Connection conn = null;
	PreparedStatement pstmt = null;

	public RegisterDaoImpl() throws RegistrationException {
		util = new DBUtil();
	}

	@Override
	public int addRegistrationDetails(UserDto user) throws RegistrationException {
		int status=0;
		try{
		conn = util.getConnection();
		String query="INSERT INTO REGISTEREDUSERS VALUES(?,?,?,?,?,?)";
		pstmt=conn.prepareStatement(query);
		pstmt.setString(1,user.getFirstname());
		pstmt.setString(2, user.getLastname());
		pstmt.setString(3, user.getPassword());
		pstmt.setString(4, String.valueOf(user.getGender()));
		pstmt.setString(5, user.getSkill());
		pstmt.setString(6, user.getCity());
		status=pstmt.executeUpdate();
		if(status==1){
			System.out.println("data inserted");
		}
		else{
			System.out.println("data not inserted");
		}
	} catch (SQLException e) {
		System.out.println("not inserted");
		e.printStackTrace();
	}finally{
		try {
			if(pstmt!=null){
				pstmt.close();
			}
			if(conn!=null){
				conn.close();
			}
		} catch (SQLException e) {
			throw new RegistrationException("Database closing failed");
		}
	}
		return status;
		
	}

	@Override
	public List<UserDto> showAll() throws RegistrationException {
		List<UserDto> myEmp = new ArrayList<UserDto>();
		try {
			conn=util.getConnection();
			String query = "SELECT FIRSTNAME,LASTNAME,PASSWORD,GENDER,SKILLSET,CITY FROM REGISTEREDUSERS";
			pstmt = conn.prepareStatement(query);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()){
				UserDto u = new UserDto();
				u.setFirstname(rs.getString(1));
				u.setLastname(rs.getString(2));
				u.setPassword(rs.getString(3));
				String gender = rs.getString(4);
				char g = gender.charAt(0);
				u.setGender(g);
				u.setSkill(rs.getString(5));
				u.setCity(rs.getString(6));
			    myEmp.add(u);
			}
			rs.close(); 
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RegistrationException("problem in show");
			
		}finally{
			try {
				if(pstmt!=null){
					pstmt.close();
				}
				if(conn!=null){
					conn.close();
				}
			} catch (SQLException e) {
				throw new RegistrationException("Database closing failed");
			}
		}
		return myEmp;
	}
	

}
