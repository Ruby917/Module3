package com.cg.lab5.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.ebillapplication.exception.EbillException;

public class DBUtil {
	private DataSource datasource;

	public DBUtil() throws EbillException {
		try {
			Context ctx = new InitialContext(); //get reference to remote JNDI
			datasource  = (DataSource) ctx.lookup("java:/OracleDS");
		} catch (NamingException e) {
			e.printStackTrace();
			throw new EbillException("failed to get JNDI Context",e);
		}
	}
	
	public Connection getConnection() throws SQLException{
		return datasource.getConnection();
	}
	
	
}
