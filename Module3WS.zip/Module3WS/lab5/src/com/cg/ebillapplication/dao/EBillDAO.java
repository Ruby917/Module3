package com.cg.ebillapplication.dao;

public interface EBillDAO {

}
