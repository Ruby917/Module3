package com.cg.ebillapplication.dao;

public class EBillDAOImpl {

	public EBillDAOImpl() {
		// TODO Auto-generated constructor stub
	}

}
