package com.cg.ebillapplication.dto;

public class BillDTO {

	public BillDTO() {
		// TODO Auto-generated constructor stub
	}

}
