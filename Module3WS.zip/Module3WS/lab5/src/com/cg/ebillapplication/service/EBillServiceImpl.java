package com.cg.ebillapplication.service;

public class EBillServiceImpl {

	public EBillServiceImpl() {
		// TODO Auto-generated constructor stub
	}

}
