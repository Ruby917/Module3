package com.cg.ebillapplication.service;

public interface EBillService {

}
