package com.cg.ebillapplication.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.ebillapplication.exception.EbillException;

@WebServlet("*.do")
public class EbillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public EbillController() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			processRequest(request, response);
		} catch (EbillException e) {
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException{
		try {
			processRequest(request, response);
		} catch (EbillException e) {
			e.printStackTrace();
		}
	}

	private void processRequest(HttpServletRequest request, HttpServletResponse response)throws ServletException, EbillException{
		String path = request.getServletPath();
		System.out.println(path);
		if(path.equals("/login.do")){
			System.out.println("in login.do");
			String userName = request.getParameter("userId");
			String password = request.getParameter("pwd");
			String nextHtml = null;
			boolean isAuthenticated = isUserAuthenticated(userName, password);
			if(isAuthenticated){
				nextHtml = "sucess.html";
				try {
					response.sendRedirect(nextHtml);
				} catch (IOException e) {
					e.printStackTrace();
					throw new EbillException("failed to login");
				}
				
			}else{
				nextHtml = "failure.html";
				try {
					response.sendRedirect(nextHtml);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	private boolean isUserAuthenticated(String userName, String password){
		if(userName.equals("rima") && password.equals("rima")){
			return true;
		}else{
			return false;
		}
	}

}
