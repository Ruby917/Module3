package com.cg.empSystem.controller;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.empSystem.dto.Employee;
import com.cg.empSystem.exception.EmployeeException;
import com.cg.empSystem.service.EmployeeService;
import com.cg.empSystem.service.EmployeeServiceImpl;

@WebServlet("*.do")
public class EmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private EmployeeService empservice = null;
	private Employee emp = null;
    
    public EmployeeServlet() throws EmployeeException {
        empservice = new EmployeeServiceImpl();
        emp = new Employee();
    }

    
    
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			processRequest(request,response);
		} catch (EmployeeException | SQLException e) {
			e.printStackTrace();
		}
	}



	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			processRequest(request,response);
		} catch (EmployeeException | SQLException e) {
			e.printStackTrace();
		}
	}

	private void processRequest(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException, EmployeeException, SQLException {
		String path = request.getServletPath();
		System.out.println(path);
		if(path.equals("/opreration.do")){
			RequestDispatcher dispatch = request.getRequestDispatcher("opr.jsp");
 			dispatch.forward(request, response);
		}
		else if(path.equals("/empadd.do")){
			try {
				String empid = request.getParameter("empid");
				String fname = request.getParameter("fname");
				String lname = request.getParameter("lname");
				String dateOfBirth = request.getParameter("dob");
				String dateOfJoining = request.getParameter("doj");
				int deptid =Integer.parseInt(request.getParameter("deptid"));
				String grade = request.getParameter("grade");
				String desig = request.getParameter("design");
				String contactNo = request.getParameter("contact");
				String gender = request.getParameter("gender");
				String marialStatus = request.getParameter("marStatus");
				String homeAddr = request.getParameter("addr");
				
				emp.setEmp_id(empid);
				emp.setEmp_fname(fname);
				emp.setEmp_lname(lname);
				String dstr1 = dateOfBirth;
				Date d1 = Date.valueOf(dstr1);
				emp.setDateOfBirth(d1);
				String dstr2 = dateOfJoining;
				Date d2 = Date.valueOf(dstr2);
				emp.setDateOfJoining(d2);
				emp.setEmp_deptId(deptid);
				emp.setEmp_grade(grade);
				emp.setDesignation(desig);
				emp.setEmp_contactNo(contactNo);
				emp.setEmp_gender(gender);
				emp.setEmp_maritalStatus(marialStatus);
				emp.setEmp_homeAddress(homeAddr);
				int st = empservice.addEmployeeDetails(emp);
				if(st==1){
					RequestDispatcher dispatch = request.getRequestDispatcher("added.jsp");
		 			dispatch.forward(request, response);
				}else{
					RequestDispatcher dispatch = request.getRequestDispatcher("erradd.jsp");
		 			dispatch.forward(request, response);
				}
			} catch (NumberFormatException e) {
				e.printStackTrace();
			} catch (EmployeeException e) {
				e.printStackTrace();
			}
		}else if(path.equals("/remove.do")){
			String enostr = request.getParameter("eno");
			int eno = Integer.parseInt(enostr);
			boolean f = empservice.RemoveEmployeeDetails(eno);
			if(f){
				RequestDispatcher dispatch = request.getRequestDispatcher("deleted.jsp");
	 			dispatch.forward(request, response);
			}else{
				RequestDispatcher dispatch = request.getRequestDispatcher("errdlt.jsp");
	 			dispatch.forward(request, response);
			}
		}else if(path.equals("/showall.do")){
			List<Employee> mylist = new ArrayList<Employee>();
			try {
				mylist = empservice.showAll();
				System.out.println(mylist);
			} catch (EmployeeException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
	       request.setAttribute("data", mylist);
	       RequestDispatcher dispatch = request.getRequestDispatcher("showall.jsp");
			dispatch.forward(request, response);
		}
	}

}
