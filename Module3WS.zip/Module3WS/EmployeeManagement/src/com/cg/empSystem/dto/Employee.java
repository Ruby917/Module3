package com.cg.empSystem.dto;

import java.sql.Date;

public class Employee {
	private String emp_id;
	private String emp_fname;
	private String emp_lname;
	private Date dateOfBirth;
	private Date dateOfJoining;
	private int emp_deptId;
	private String emp_grade;
	private String designation;
	private String emp_gender;
	private String emp_maritalStatus;
	private String emp_homeAddress;
	private String emp_contactNo;
	
	public Employee() {
	}
	
	public Employee(String emp_id, String emp_fname, String emp_lname,
			Date dateOfBirth, Date dateOfJoining, int emp_deptId,
			String emp_grade, String designation, String emp_gender,
			String emp_maritalStatus, String emp_homeAddress,
			String emp_contactNo) {
		super();
		this.emp_id = emp_id;
		this.emp_fname = emp_fname;
		this.emp_lname = emp_lname;
		this.dateOfBirth = dateOfBirth;
		this.dateOfJoining = dateOfJoining;
		this.emp_deptId = emp_deptId;
		this.emp_grade = emp_grade;
		this.designation = designation;
		this.emp_gender = emp_gender;
		this.emp_maritalStatus = emp_maritalStatus;
		this.emp_homeAddress = emp_homeAddress;
		this.emp_contactNo = emp_contactNo;
	}

	@Override
	public String toString() {
		return "Employee [emp_id=" + emp_id + ", emp_fname=" + emp_fname
				+ ", emp_lname=" + emp_lname + ", dateOfBirth=" + dateOfBirth
				+ ", dateOfJoining=" + dateOfJoining + ", emp_deptId="
				+ emp_deptId + ", emp_grade=" + emp_grade + ", designation="
				+ designation + ", emp_gender=" + emp_gender
				+ ", emp_maritalStatus=" + emp_maritalStatus
				+ ", emp_homeAddress=" + emp_homeAddress + ", emp_contactNo="
				+ emp_contactNo + "]";
	}

	public String getEmp_id() {
		return emp_id;
	}

	public void setEmp_id(String emp_id) {
		this.emp_id = emp_id;
	}

	public String getEmp_fname() {
		return emp_fname;
	}

	public void setEmp_fname(String emp_fname) {
		this.emp_fname = emp_fname;
	}

	public String getEmp_lname() {
		return emp_lname;
	}

	public void setEmp_lname(String emp_lname) {
		this.emp_lname = emp_lname;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Date getDateOfJoining() {
		return dateOfJoining;
	}

	public void setDateOfJoining(Date dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}

	public int getEmp_deptId() {
		return emp_deptId;
	}

	public void setEmp_deptId(int emp_deptId) {
		this.emp_deptId = emp_deptId;
	}

	public String getEmp_grade() {
		return emp_grade;
	}

	public void setEmp_grade(String emp_grade) {
		this.emp_grade = emp_grade;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getEmp_gender() {
		return emp_gender;
	}

	public void setEmp_gender(String emp_gender) {
		this.emp_gender = emp_gender;
	}

	public String getEmp_maritalStatus() {
		return emp_maritalStatus;
	}

	public void setEmp_maritalStatus(String emp_maritalStatus) {
		this.emp_maritalStatus = emp_maritalStatus;
	}

	public String getEmp_homeAddress() {
		return emp_homeAddress;
	}

	public void setEmp_homeAddress(String emp_homeAddress) {
		this.emp_homeAddress = emp_homeAddress;
	}

	public String getEmp_contactNo() {
		return emp_contactNo;
	}

	public void setEmp_contactNo(String emp_contactNo) {
		this.emp_contactNo = emp_contactNo;
	}


	

}
