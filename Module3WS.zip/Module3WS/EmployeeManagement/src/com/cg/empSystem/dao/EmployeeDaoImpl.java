package com.cg.empSystem.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.empSystem.dto.Employee;
import com.cg.empSystem.exception.EmployeeException;
import com.cg.empSystem.util.DBUtil;

public class EmployeeDaoImpl implements EmployeeDao{
	private DBUtil util;
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	public EmployeeDaoImpl() throws EmployeeException {
		util = new DBUtil();
	}

	@Override
	public int addEmployeeDetails(Employee emp) throws EmployeeException {
		int status = 0;
		try {
			conn = util.getConnection();
			String query="INSERT INTO EMPLOYEE VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
			pstmt=conn.prepareStatement(query);
			pstmt.setString(1,emp.getEmp_id());
			pstmt.setString(2, emp.getEmp_fname());
			pstmt.setString(3, emp.getEmp_lname());
			pstmt.setDate(4, emp.getDateOfBirth());
			pstmt.setDate(5, emp.getDateOfJoining());
			pstmt.setInt(6, emp.getEmp_deptId());
			pstmt.setString(7, emp.getEmp_grade());
			pstmt.setString(8, emp.getDesignation());
			pstmt.setString(9, emp.getEmp_gender());
			pstmt.setString(10, emp.getEmp_maritalStatus());
			pstmt.setString(11, emp.getEmp_homeAddress());
			pstmt.setString(12, emp.getEmp_contactNo());
			status=pstmt.executeUpdate();
			if(status==1){
				System.out.println("data inserted");
			}
			else{
				System.out.println("data not inserted");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				if(rs!=null){
						rs.close();
				}
				if(pstmt!=null){
					pstmt.close();
				}
				if(conn!=null){
					conn.close();
				}
			} catch (SQLException e) {
				throw new EmployeeException("Database closing failed",e);
			}
		}
		return status;
	}
	public boolean RemoveEmployeeDetails(int empid) throws EmployeeException, SQLException {
		conn = util.getConnection();
		int rec = 0;
		String query = "DELETE FROM EMPLOYEE where EMP_ID=?";
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, empid);
			rec = pstmt.executeUpdate();
			if (rec > 0)
				return true;
		} catch (SQLException e) {
			System.out.println(e);
			
		} finally {
			try {
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				System.out.println(e);
				throw new EmployeeException("Data Not Removed",e);
			}

		}

		return false;
	}

	@Override
	public List<Employee> showAll() throws EmployeeException, SQLException {
		List<Employee> myEmp = new ArrayList<Employee>();
		conn=util.getConnection();
		String query = "SELECT EMP_ID, EMP_FIRST_NAME, EMP_LAST_NAME, EMP_DATE_OF_BIRTH, EMP_DATE_OF_JOINING, EMP_DEPT_ID, EMP_GRADE, EMP_DESIGNATION, EMP_GENDER, EMP_MARITAL_STATUS, EMP_HOME_ADDRESS, EMP_CONTACT_NUM FROM EMPLOYEE";
		try {
			pstmt = conn.prepareStatement(query);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()){
			  Employee e = new Employee();
			  e.setEmp_id(rs.getString("EMP_ID"));
			  e.setEmp_fname(rs.getString("EMP_FIRST_NAME"));
			  e.setEmp_lname(rs.getString("EMP_LAST_NAME"));
			  e.setDateOfBirth(rs.getDate("EMP_DATE_OF_BIRTH"));
			  e.setDateOfJoining(rs.getDate("EMP_DATE_OF_JOINING"));
			  e.setEmp_deptId(rs.getInt("EMP_DEPT_ID"));
			  e.setEmp_grade(rs.getString("EMP_GRADE"));
			  e.setDesignation(rs.getString("EMP_DESIGNATION"));
			  e.setEmp_gender(rs.getString("EMP_GENDER"));
			  e.setEmp_maritalStatus(rs.getString("EMP_MARITAL_STATUS"));
			  e.setEmp_homeAddress(rs.getString("EMP_HOME_ADDRESS"));
			  e.setEmp_contactNo(rs.getString("EMP_CONTACT_NUM"));
			  myEmp.add(e);
			}
			rs.close(); 
		} catch (SQLException e) {
			e.printStackTrace();
			throw new EmployeeException("problem in show");
			
		}finally{
			try {
				if(pstmt!=null){
					pstmt.close();
				}
				if(conn!=null){
					conn.close();
				}
			} catch (SQLException e) {
				throw new EmployeeException("Database closing failed");
			}
		}
		return myEmp;
	}
	

}
