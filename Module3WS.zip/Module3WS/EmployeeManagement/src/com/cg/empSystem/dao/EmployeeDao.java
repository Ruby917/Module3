package com.cg.empSystem.dao;

import java.sql.SQLException;
import java.util.List;

import com.cg.empSystem.dto.Employee;
import com.cg.empSystem.exception.EmployeeException;



public interface EmployeeDao {
	public int addEmployeeDetails(Employee emp) throws EmployeeException;
	public boolean RemoveEmployeeDetails(int empid) throws EmployeeException, SQLException;
	public List<Employee> showAll() throws EmployeeException, SQLException;
}
