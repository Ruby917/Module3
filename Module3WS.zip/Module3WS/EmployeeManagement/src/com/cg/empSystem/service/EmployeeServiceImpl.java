package com.cg.empSystem.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.empSystem.dao.EmployeeDao;
import com.cg.empSystem.dao.EmployeeDaoImpl;
import com.cg.empSystem.dto.Employee;
import com.cg.empSystem.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService{
	EmployeeDao empdao = null;
	public EmployeeServiceImpl() throws EmployeeException {
		empdao = new EmployeeDaoImpl();
	}

	@Override
	public int addEmployeeDetails(Employee emp) throws EmployeeException {
		return empdao.addEmployeeDetails(emp);
	}

	@Override
	public boolean RemoveEmployeeDetails(int empid) throws EmployeeException,SQLException {
		return empdao.RemoveEmployeeDetails(empid);
	}

	@Override
	public List<Employee> showAll() throws EmployeeException, SQLException {
		return empdao.showAll();
	}

}
