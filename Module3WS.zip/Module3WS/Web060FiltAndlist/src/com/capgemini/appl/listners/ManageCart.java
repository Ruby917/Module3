package com.capgemini.appl.listners;

import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

@WebListener
public class ManageCart implements HttpSessionListener {

    public void sessionCreated(HttpSessionEvent arg0)  { 
    	System.out.println("in session listner created");
    	
    }

    public void sessionDestroyed(HttpSessionEvent arg0)  { 
    	System.out.println("in session listner distroyed");
    }
	
}
