package com.capgemini.appl.listners;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

@WebListener
public class CreateContextListner implements ServletContextListener {
	
    public void contextInitialized(ServletContextEvent arg0)  {
    	System.out.println("Context initialize() - CreateContxtListner");
    	
    }

    public void contextDestroyed(ServletContextEvent arg0)  {
    	System.out.println("Context destroyed() - CreateContxtListner");
    }

	
}
