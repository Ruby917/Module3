package com.capgemini.magicworld.Exceptions;

public class ShowException extends Exception {
	/**
	 * Author		:	Ruby Singh
	 * Class Name	:	BillException
	 * Package		:	com.capgemini.electricity.exception
	 * Date			:	14-Mar-2017
	 */


	private static final long serialVersionUID = 1L;

	public ShowException() {
		
	}

	public ShowException(String message) {
		super(message);
	
	}

	public ShowException(Throwable cause) {
		super(cause);
		
	}

	public ShowException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public ShowException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		
	}

}
