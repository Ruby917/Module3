package com.capgemini.magicworld.dto;

import java.sql.Date;


/**
 * Author		:	Ruby Singh
 * Class Name	:	BillDto
 * Package		:	com.capgemini.electricity.dto
 * Date			:	14-Mar-2017
 */


public class Show {
	private String showId;
	private String showName;
	private String location;
	private  Date showDate;
	private int avlSeats;
	private double tktPrice;
	
	
	
	public Show() {
		super();
	}



	public Show(String showId, String showName, String location, Date showDate,
			int avlSeats, double tktPrice) {
		super();
		this.showId = showId;
		this.showName = showName;
		this.location = location;
		this.showDate = showDate;
		this.avlSeats = avlSeats;
		this.tktPrice = tktPrice;
	}



	public String getShowId() {
		return showId;
	}



	public void setShowId(String showId) {
		this.showId = showId;
	}



	public String getShowName() {
		return showName;
	}



	public void setShowName(String showName) {
		this.showName = showName;
	}



	public String getLocation() {
		return location;
	}



	public void setLocation(String location) {
		this.location = location;
	}



	public Date getShowDate() {
		return showDate;
	}



	public void setShowDate(Date showDate) {
		this.showDate = showDate;
	}



	public int getAvlSeats() {
		return avlSeats;
	}



	public void setAvlSeats(int avlSeats) {
		this.avlSeats = avlSeats;
	}



	public double getTktPrice() {
		return tktPrice;
	}



	public void setTktPrice(double tktPrice) {
		this.tktPrice = tktPrice;
	}



	@Override
	public String toString() {
		return "Show [showId=" + showId + ", showName=" + showName
				+ ", location=" + location + ", showDate=" + showDate
				+ ", avlSeats=" + avlSeats + ", tktPrice=" + tktPrice + "]";
	}
	
	
}
